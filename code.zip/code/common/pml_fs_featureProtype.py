"""
结果为具备该标签的所有instance的特征平均值
"""
import numpy as np


def featureProtype(Xtr, Ytr):
    num_class = Ytr.shape[0]
    dim = Xtr.shape[1]
    Q = np.zeros((num_class, dim), dtype=float)
    for k in range(num_class - 1):
        inds = np.argwhere(Ytr[k, :] == 1)
        inds = inds.T
        Q[k, :] = sum(Xtr[inds, :][0]) / len(inds)  # Xtr变型后为134*72
    return Q