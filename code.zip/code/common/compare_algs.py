
from skmultilearn.adapt import MLkNN
import numpy as np

def ML_KNN_ALG(mul_Ytr, Xtr, Xte):
    # classifier = MLkNN(k=10, s=1.0, ignore_first_neighbours=0)
    classifier = MLkNN()
    mlknn_ytr = mul_Ytr.T
    mlknn_ytr = mlknn_ytr.astype(np.float64)
    classifier.fit(Xtr, mlknn_ytr)
    predictions = classifier.predict(Xte)
    pre_proba = classifier.predict_proba(Xte)

    return predictions, pre_proba