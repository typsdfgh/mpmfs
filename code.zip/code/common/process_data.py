"""
预处理函数
"""

import numpy as np
import scipy.io as io
import matlab
import csv
import pandas as pd
from numpy import linalg as LA
eps = 2.2204e-16


def delete_zero(target, partial_labels, ori_data):
    label_delete = []
    instance_delete = []
    # 确定存在有此label对应的instance
    count = 0
    row = target.shape[0]
    ori_target = target.copy()
    for i in range(row):
        temp = ori_target[i]
        if np.isin(temp, [0]).all() or np.isin(temp, [-1]).all():
            print(i, '需要替换此行')
            target = np.delete(target, i - count, axis=0)
            partial_labels = np.delete(partial_labels, i - count, axis=0)
            label_delete.append(i)
            count += 1

    # 确定存在有此instance对应的label
    count = 0
    y = target.T
    for j in range(y.shape[0]):
        temp = y[j]
        if np.isin(temp, [0]).all() or np.isin(temp, [1]).all() or np.isin(temp, [-1]).all():
            #print(j, '删除该instance')
            target = np.delete(target, j - count, axis=1)
            ori_data = np.delete(ori_data, j - count, axis=0)
            partial_labels = np.delete(partial_labels, j - count, axis=1)
            instance_delete.append(j)
            count += 1
    return target, partial_labels, ori_data,label_delete,instance_delete

def read_mat_data(filename):
    matr1 = io.loadmat(filename)
    # matr1 = io.loadmat('.\\YeastMF.mat')
    data = matr1['data']
    target = matr1['target']
    partial_labels = matr1['partial_labels']
    # partial_labels = matr1['candidate_labels']
    return data, target, partial_labels

def python_to_matlab_matrix(x, eng):
    x = np.transpose(x)
    test_data = x.reshape(-1, 1)
    test_data = test_data.tolist()
    test_data = matlab.double(test_data)
    test_data = eng.reshape(test_data, x.shape[1], x.shape[0])
    return test_data

def read_general_mat_data(filename):
    matr1 = io.loadmat(filename)
    matr1_list = list(matr1.keys())
    #print(matr1_list)
    para = {}
    for i in range(3, len(matr1_list)):
        para[matr1_list[i]] = matr1[matr1_list[i]]

    return para

def read_compare_exp_result(matr):
    HammingLoss = matr['HammingLoss']
    RankingLoss = matr['RankingLoss']
    OneError = matr['OneError']
    Coverage = matr['Coverage']
    Average_Precision = matr['Average_Precision']
    Outputs = matr['Outputs']
    Pre_Labels = matr['Pre_Labels']
    return HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels

def write_to_csv_file(filename, result):
    if len(result) == 0:
        return
    with open(filename,'w',newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision','F1-micro','F1-macro'])
        for i in result:
            writer.writerow(i)

def write_to_fselect_file(filename, result):
    if len(result) == 0:
        return
    with open(filename,'w',newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['feature_num','HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision','F1-micro','F1-macro','duration'])
        count = 1
        for i in result:
            writer.writerow([count] + i)
            count +=1

def write_to_best_file(filename, result):
    if len(result) == 0:
        return
    with open(filename,'w',newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['dataset','HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision','F1_micro','F1_macro','h1','h2','h3','h4'])
        for i in result:
            writer.writerow(i)

def process_mean(result):
    if len(result) == 0:
        return 0
    array_final =np.array(result)
    mean_final = array_final.mean(axis=0)
    return mean_final

def get_W_process(X, Y, temp_name):

    num, dim = X.shape
    num, label_num = Y.shape

    W = np.random.rand(dim, label_num)
    iter = 0
    obj = []
    obji = 1

    while 1:
        temp1 = np.dot(X.T, Y)
        temp2 = np.dot(np.dot(X.T, X),W) + eps

        W = np.multiply(W, np.true_divide(temp1, temp2))
        objectives = pow(LA.norm(np.dot(X, W) - Y, 'fro'), 2)

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break
    # 写入文件
    pd_data = pd.DataFrame(W)
    # pd_data.to_csv(".//temp_result_w_idea1//test.csv", header=None, index=False)
    pd_data.to_csv(temp_name, header=None, index=False)
    return W

"""
    obj_value = np.array(obj)
    obj_function_value = []
    for i in range(iter):
        temp_value = float(obj_value[i])
        obj_function_value.append(temp_value)

    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    l = [i for i in idx]
    n = 1
    F = [l[i:i + n] for i in range(0, len(l), n)]
    F = np.matrix(F)

    ll = [i for i in obj_function_value]
    n = 1
    F_value = [ll[i:i + n] for i in range(0, len(ll), n)]
    F_value = np.matrix(F_value)
    #return F[0:select_nub, :], F_value[:, :], iter
"""


def update_metrics(result, f,i, HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, F1_micro, F1_macro,d3):
    h = (result[f - 1][0] * i + HammingLoss[0][0]) / (i + 1)
    r = (result[f - 1][1] * i + RankingLoss[0][0]) / (i + 1)
    o = (result[f - 1][2] * i + OneError[0][0]) / (i + 1)
    c = (result[f - 1][3] * i + Coverage[0][0]) / (i + 1)
    a = (result[f - 1][4] * i + Average_Precision[0][0]) / (i + 1)
    fi = (result[f - 1][5] * i + F1_micro) / (i + 1)
    fa = (result[f - 1][6] * i + F1_macro) / (i + 1)
    d = (result[f - 1][7] * i + d3) / (i + 1)
    return h, r, o, c, a, fi, fa, d

def feature_selection(temp_W, select_nub, label_num,feature_num):
    score = np.sum(np.multiply(temp_W, temp_W),1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]
    l_new = np.array(l[:select_nub])
    remove_col = np.setdiff1d(np.arange(feature_num), l_new)
    new_W = temp_W.copy()
    new_W[remove_col, :] = np.zeros(label_num)

    return new_W