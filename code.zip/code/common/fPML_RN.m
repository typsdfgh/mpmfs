% fMPL_RN:  Identify noisy labels for three general multi-label datasets (during the experiments, these three datasets will be injected additional noisy labels).
%   input data:
%       data:      - matrix: nxd, feature matrix, the i-th instance is stored in data(i,:)
 %      target:    - matrix: nxq, label association matrix, if the j-th class label is one of the labels for the i-th instance, then target(i,j) equals +1, otherwise 0.

 
 function  [ ]=fPML_RN(Xtr, Ytr, Xte, Yte, Ypte, i, lamda1,lamda2,lamda3,file_count)
%fprintf('\n =====%s begin fPML_RN time=%s\n',dataset,datestr(now));
%load(dataset);
repeat=1;%10
[num_ins, num_labels]=size(Ytr);
[num_ins, dim] = size(Xtr)
%lamda1=0.1;
%lamda2=1;
%lamda3=10;
noisy_num=3;
r=num_labels;

%target=transpose(target);
%partial_labels=transpose(partial_labels);
Xtr=double(Xtr)
Ytr=double(Ytr)
Xte=double(Xte);
Yte=double(Yte)
Ypte=double(Ypte)
Ytr=transpose(Ytr);
Yte=transpose(Yte);
Ypte = transpose(Ypte);

%Y=target;
%X=data;
%Y_noisy=partial_labels;

Y = Yte
X = Xtr;
Y_noisy = Ytr;


RankingLosses1 =zeros(1,repeat);
OneErrors1 =zeros(1,repeat);
AveragePrecisions1 =zeros(1,repeat);
%%
for  run=1:repeat
    %原rand_noisy
    %Y_noisy = rand_noisy(Y,noisy_num);%inject noisy_num noisy labels
    %=============identify noisy labels============================================='
    [P, W] =fPML_train( X, Y_noisy, lamda1, lamda2,  lamda3, r);
    filename = ['.\\result_W\\save_fpml_W_' num2str(file_count)  '_' num2str(i) '.mat'];
    save(filename, 'W');
    %predict_values=P.*Y_noisy;
    test = 1:dim;
    W_test=W(test,:);
    predict_values=(Xte * W_test).*Ypte;
    % ======================Evaluation=================================
    %[RankingLosses2,OneErrors2,AveragePrecisions2,Hamminglosses2,coverages2,Outputs,Pre_Labels]=evaluate2(predict_values, Y);
    [RankingLosses2,OneErrors2,AveragePrecisions2,Hamminglosses2,coverages2,Outputs,Pre_Labels]=evaluate2(predict_values, Yte);
    RankingLosses1(run) =RankingLosses2;
    OneErrors1(run) =OneErrors2;
    AveragePrecisions1(run) =AveragePrecisions2;
    Hamminglosses1(run) =Hamminglosses2;
    coverages1(run) =coverages2;
end

RankingLoss=mean(RankingLosses1,2);
OneError = mean(OneErrors1,2);
Average_Precision =mean(AveragePrecisions1,2);
HammingLoss=mean(Hamminglosses1,2);
Coverage=mean(coverages1,2);


evaluation=cell(5,1);
evaluation{1} =RankingLoss;
evaluation{2}=OneError;
evaluation{3}=Average_Precision;
evaluation{4}=HammingLoss;
evaluation{5}=Coverage;

save('.\\test_save_fpml_test_result.mat', 'HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision','Outputs','Pre_Labels');
%prec_seq='RankingLosses, OneErrors, AveragePrecisions';
%evalstr=['save .\\results',filesep,dataset,'_fPML_RN.mat evaluation'];
%eval(evalstr);
end


