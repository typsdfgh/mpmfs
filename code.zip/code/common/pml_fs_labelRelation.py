"""
计算label的corr，以label同时出现的几率为corr定义，详见Diplaris et al.2005
"""
import numpy as np
import math


def labelRelation(Ytr):
    num_class = Ytr.shape[0]
    S = np.zeros((num_class, num_class), dtype=float)
    for i in range(num_class):
        for j in range(num_class):
            if i != j:
                A = np.sum((Ytr[i,:] == 1) & (Ytr[j,:] == 1))
                B = np.sum((Ytr[i,:] == 1) & (Ytr[j,:] == -1))
                C = np.sum((Ytr[i,:] == -1) & (Ytr[j,:] == 1))
                D = np.sum((Ytr[i,:] == -1) & (Ytr[j,:] == -1))

                S[i,j] = (A * D - B * C) / np.sqrt((A + B) * (C + D) * (A + C) * (B + D))
                if math.isnan(S[i,j]):
                    print(i,j,"出现NAN")


    S_max = np.nanmax(S)
    S_min = np.nanmin(S)
    S = (S - S_min) / (S_max - S_min)

    for i in range(num_class):
        S[i,i] = 0

    return S