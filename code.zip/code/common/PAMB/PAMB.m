function aa = PAMB(data,partial_labels,target,multiLength,desert_num)

% PAMB performs ten-fold cross validation on PML datasets. It divides the original data into nine fold for training and one fold for testing.
% 
% Syntax
%     aa = PAMB(data,partial_labels,target,multiLength,desert_num)
%
% Description
%     PAMB takes,
%         data                   - A n_sample x n_fea array, the ith instance of PML training instance is stored in data(i,:).  
%         partial_labels         - A num_class x n_sample array, if the jth class label is one of the candidate labels for the ith instance, then partial_labels(j,i) equals to 1, otherwise 0.
%         target                 - A num_class x n_sample array, if the jth class label is one of the ground-truth labels for the ith instance, the target(j,i) equals to 1, otherwise 0.
%         multiLength            - The coefficient of CodewordLength (default 100). CodewordLength is the number of columns of coding matrix.
%         desert_num             - The number of '0' in the ternary coding vector (default ceil(#avg.GLS-1) for sufficient data and ceil(#avg.GLS+2) for insufficient data).
%                                - It is suggested that the parity of desert_num is consistent with num_class by adding or subtracting 1.
%     and returns
%         aa                     - The experimental results on testing data after ten-fold cross validation.

    nfold = 10; % ten-fold cross validation
    [n_sample,n_fea] = size(data);

    % min-max normalization
    for i=1:n_fea
        if size(unique(data(:,i)),1)~=1
            data(:,i)=(data(:,i)-min(min(data(:,i))))/(max(max(data(:,i)))-min(min(data(:,i))));
        end
    end

    result=zeros(nfold,6);
    n_test = round(n_sample/nfold);
    I = 1:n_sample;

    
    parfor i=1:nfold  % parfor needs Parallel Computing Toolbox in Matlab
        fprintf('result processing,Cross validation: %d\n', i);

        % divide training and testing data
        start_ind = (i-1)*n_test + 1;
        if start_ind+n_test-1 > n_sample
            test_ind = start_ind:n_sample;
        else
            test_ind = start_ind:start_ind+n_test-1;
        end
        
        train_ind = setdiff(I,test_ind);
        train_data = data(train_ind, :);
        train_target=partial_labels(:,train_ind);
        test_data = data(test_ind,:);
        test_target = target(:, test_ind);

        thr = ceil(0.01 * size(train_data,1)); % lower bound of sample size of the derived binary training set
        CodewordLength = round(multiLength * log2(size(train_target,1))); % the number of columns of coding matrix
        
        gamma = 1;
        str=strcat(' -t 2 -g',32,num2str(gamma),' -q'); % parameters in libsvm, we use RBF kernel for better noise-resisting ability
        
        % train a multi-label classifier
        model = PAMB_train(train_data,train_target,CodewordLength,thr,str,desert_num);
        
        % predict on testing data
        [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,MicroF1,Pre_Labels,outputValue] = PAMB_predict(test_data,test_target,model);
        
        result(i,:) = [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,MicroF1];
        
        disp(result(i,:)')
    end
    
    % calculate the mean and standard deviation
    result1=sum(result)/nfold;
    rr1=std(result);
    aa=[result1',rr1'];

end

