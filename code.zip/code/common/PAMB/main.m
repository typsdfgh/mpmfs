clear
clc

dataset='emotions3';
desert_num=2; % the number of '0' in the ternary coding vector
multiLength=100; % the coefficient of CodewordLength

load(dataset); 
result=PAMB(data,partial_labels,target,multiLength,desert_num);
filename=strcat('result_',dataset,'.mat');
save(filename,'result');

