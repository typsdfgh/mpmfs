function cl_result_record(cl_record, cl_path, column, title)
    % 以追加的方式写入一条数据到 CSV 文件
    % 输入参数：
    %   cl_record: 单条分类记录，struct 格式
    %   cl_path: 存储 CSV 文件的路径
    %   column: CSV 文件的列名，cell 数组
    %   title: 是否写入列名，1 表示写入，0 表示不写入

    % 创建 struct 数组
    if title == 1
        data = column;
    else
        data = cl_record;
    end
    data_table = struct2table(data);

    % 打开或创建 CSV 文件
    if title == 1
        writetable(data_table, cl_path, 'Delimiter', ',');
    else
        writetable(data_table, cl_path, 'Delimiter', ',', 'WriteMode', 'append');
    end

    disp('数据已追加到 CSV 文件。');
end
