
function W = get_W_process(X, Y)
    [num, dim] = size(X);
    [num, label_num] = size(Y);

    W = rand(dim, label_num);
    iter = 0;
    obj = [];
    obji = 1;
    eps = 1e-9;

    while true
        temp1 = X' * Y;
        temp2 = X' * X * W + eps;

        W = W .* (temp1 ./ temp2);
        objectives = norm(X * W - Y, 'fro')^2;

        obj = [obj, objectives];
        cver = abs((objectives - obji) / obji);
        obji = objectives;
        iter = iter + 1;
        if (iter > 2 && (cver < 1e-3 || iter == 1000))
            break;
        end
    end
end
