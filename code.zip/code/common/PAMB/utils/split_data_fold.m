function [x_train, x_test, y_train, y_test, l_train, l_test] = split_data_fold(view, label, partial_label, k_no, n_fold)
    % K-fold cross-validation, get the data for the K-th fold
    % Inputs:
    % view: Feature data
    % label: True labels
    % partial_label: Partial labels
    % k_no: Current fold number
    % n_fold: Total number of folds
    % Outputs:
    % x_train: Training feature data
    % x_test: Testing feature data
    % y_train: Training true labels
    % y_test: Testing true labels
    % l_train: Training partial labels
    % l_test: Testing partial labels
    
    n_sample = size(view, 1);
    n_test = round(n_sample / n_fold); % Number of samples in each fold
    
    % Get the indices for training and testing samples
    start_idx = k_no * n_test;
    if (start_idx + n_test) > n_sample
        testIdx = start_idx + 1:n_sample;
    else
        testIdx = start_idx + 1:(start_idx + n_test);
    end
    trainIdx = setdiff(1:n_sample, testIdx);
    
    % Feature sets
    x_train = view(trainIdx, :);
    x_test = view(testIdx, :);
    
    % True label sets
    y_train = label(trainIdx, :);
    y_test = label(testIdx, :);
    
    % Partial label sets
    l_train = partial_label(trainIdx, :);
    l_test = partial_label(testIdx, :);
end