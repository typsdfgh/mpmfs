function [x_train, x_test, y_train, y_test, l_train, l_test] = split_data_fold(view, label, partial_label, k_no, n_fold)
    % K-fold cross-validation, get the data for the K-th fold
    % Inputs:
    % view: Feature data
    % label: True labels
    % partial_label: Partial labels
    % k_no: Current fold number
    % n_fold: Total number of folds
    % Outputs:
    % x_train: Training feature data
    % x_test: Testing feature data
    % y_train: Training true labels
    % y_test: Testing true labels
    % l_train: Training partial labels
    % l_test: Testing partial labels
    
    n_sample = size(view, 1);
    n_test = round(n_sample / n_fold); % Number of samples in each fold
    
    % Get the indices for training and testing samples
    start_idx = k_no * n_test;
    if (start_idx + n_test) > n_sample
        testIdx = start_idx + 1:n_sample;
    else
        testIdx = start_idx + 1:(start_idx + n_test);
    end
    trainIdx = setdiff(1:n_sample, testIdx);
    
    % Feature sets
    x_train = view(trainIdx, :);
    x_test = view(testIdx, :);
    
    % True label sets
    y_train = label(trainIdx, :);
    y_test = label(testIdx, :);
    
    % Partial label sets
    l_train = partial_label(trainIdx, :);
    l_test = partial_label(testIdx, :);
end

function [x_train, x_test, y_train, y_test, l_train, l_test] = remove_uniform_labels(x_train, x_test, y_train, y_test, l_train, l_test)
    % Check if there are columns in the training and testing sets with all zeros or all ones as labels
    % If such columns exist, remove them from both training and testing sets
    % Inputs:
    % x_train: Training data
    % x_test: Testing data
    % y_train: Training true labels
    % y_test: Testing true labels
    % l_train: Training noisy labels
    % l_test: Testing noisy labels
    % Outputs:
    % Processed data and label sets
    
    % Find columns in training and testing sets with all zeros or all ones
    cols_to_delete_y = find(all(y_train == 0, 1) | all(y_train == 1, 1) | all(y_test == 0, 1) | all(y_test == 1, 1));
    cols_to_delete_l = find(all(l_train == 0, 1) | all(l_train == 1, 1) | all(l_test == 0, 1) | all(l_test == 1, 1));
    
    % Merge and remove duplicates from the arrays
    cols_to_delete = unique([cols_to_delete_y, cols_to_delete_l]);
    
    % Remove these columns from the training and testing sets
    y_train(:, cols_to_delete) = [];
    y_test(:, cols_to_delete) = [];
    l_train(:, cols_to_delete) = [];
    l_test(:, cols_to_delete) = [];
end

function X_normalized = normalize(X)
    % Normalize the feature set X.
    % X has dimensions n*d, where n is the number of samples and d is the number of features.
    % Inputs:
    % X: A numpy array with dimensions n*d
    % Output:
    % X_normalized: The normalized X
    
    % Calculate the minimum and maximum values for each feature
    X_min = min(X, [], 1);
    X_max = max(X, [], 1);

    % Perform min-max normalization
    eps = 1e-9; % A small epsilon value to avoid division by zero
    X_normalized = (X - X_min) ./ (X_max - X_min + eps);
end

function fs_result_record(fs_record, fs_path, column, title)
    % Write feature selection results to a CSV file in append mode
    % Inputs:
    % fs_record: A dictionary containing feature selection results
    % fs_path: Path to the CSV file
    % column: A cell array containing column names
    % title: Boolean indicating whether to include a header row
    
    if title == false
        % Convert the dictionary to a table for easy CSV storage
        param_record = fs_record.param;
        fs_record = rmfield(fs_record, 'param');
        
        for param = fieldnames(param_record)'
            fs_record.(param{1}) = param_record.(param{1});
        end
        
        T = struct2table(fs_record);
        writetable(T, fs_path, 'WriteMode', 'append', 'Header', false);
    else
        T = table('Size', [0, numel(column)], 'VariableNames', column);
        writetable(T, fs_path, 'WriteMode', 'append', 'Header', true);
    end
end
function cl_result_record(cl_record, cl_path, column, title)
    % 以追加的方式写入一条数据到 CSV 文件
    % 输入参数：
    %   cl_record: 单条分类记录，struct 格式
    %   cl_path: 存储 CSV 文件的路径
    %   column: CSV 文件的列名，cell 数组
    %   title: 是否写入列名，1 表示写入，0 表示不写入

    % 创建 struct 数组
    if title == 1
        data = struct();
    else
        data = cl_record;

function W = get_W_process(X, Y)
    [num, dim] = size(X);
    [num, label_num] = size(Y);

    W = rand(dim, label_num);
    iter = 0;
    obj = [];
    obji = 1;
    eps = 1e-9;

    while true
        temp1 = X' * Y;
        temp2 = X' * X * W + eps;

        W = W .* (temp1 ./ temp2);
        objectives = norm(X * W - Y, 'fro')^2;

        obj = [obj, objectives];
        cver = abs((objectives - obji) / obji);
        obji = objectives;
        iter = iter + 1;
        if (iter > 2 && (cver < 1e-3 || iter == 1000))
            break;
        end
    end
end
    end

    % 将 cl_record 中的字段添加到 struct 数组中
    field_names = fieldnames(cl_record);
    for i = 1:length(field_names)
        field_name = field_names{i};
        data.(field_name) = cl_record.(field_name);
    end

    % 将数据保存到 CSV 文件
    if title == 1
        write_mode = 'w';
    else
        write_mode = 'a';
    end

    % 将 struct 数据写入 CSV 文件
    struct2csv(data, cl_path, 'WriteMode', write_mode, 'Header', title, 'Delimiter', ',');

    disp('数据已追加到 CSV 文件。');
end

