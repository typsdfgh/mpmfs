function X_normalized = normalize(X)
    % Normalize the feature set X.
    % X has dimensions n*d, where n is the number of samples and d is the number of features.
    % Inputs:
    % X: A numpy array with dimensions n*d
    % Output:
    % X_normalized: The normalized X
    
    % Calculate the minimum and maximum values for each feature
    X_min = min(X, [], 1);
    X_max = max(X, [], 1);

    % Perform min-max normalization
    eps = 1e-9; % A small epsilon value to avoid division by zero
    X_normalized = (X - X_min) ./ (X_max - X_min + eps);
end