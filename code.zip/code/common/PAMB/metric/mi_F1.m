function MicroF1 = mi_F1(Pre_Labels,test_target)
% 每一列表示一个样本
%正样本1，负样本0，对输入参数进行调整
Pre_Labels(Pre_Labels==-1)=0;
test_target(test_target==-1)=0;
Pre_Labels=double(Pre_Labels);
test_target=double(test_target);

[num_class,num_instance]=size(Pre_Labels);

TP=0;
FP=0;
FN=0;
for j=1:num_class
    temp=Pre_Labels(j,:).*test_target(j,:);
    TP=TP+sum(temp);
    FP=FP+sum(Pre_Labels(j,:))-sum(temp);
    FN=FN+sum(test_target(j,:))-sum(temp);
end
MicroF1=2*TP/(2*TP+FN+FP);
end

