function model = PAMB_train(train_data,train_target,CodewordLength,thr,str,desert_num)

% PAMB_train transforms the PML learning problem into a number of binary learning problems by error correcting output codes (ECOC).
% It divides the original PML dataset into a number of binary training sets and trains binary classifiers by libsvm,
% then calculate the empirical performance of these classifiers to acquire a performance matrix.
% 
% Syntax
%     model = PAMB_train(train_data,train_target,CodewordLength,thr,str,desert_num)
%
% Description
%     PAMB_train takes,
%         train_data             - A num_train x num_fea array, the ith instance of training instance is stored in train_data(i,:).
%         train_target           - A num_class x num_train array, if the jth class label is one of the candidate labels for the ith training instance, then train_target(j,i) equals to 1, otherwise 0.
%         CodewordLength         - The number of columns of coding matrix.
%         thr                    - Lower bound of sample size of the derived binary training set.
%         str                    - Parameters in libsvm, we use RBF kernel for better noise-resisting ability
%         desert_num             - The number of '0' in the ternary coding vector (default ceil(#avg.GLS-1) for sufficient data and ceil(#avg.GLS+2) for insufficient data).
%     and returns,
%         model                  - The set of derived binary classifiers and the performance matrix.

addpath(genpath(pwd));
[num_train,num_fea]=size(train_data);
num_class=size(train_target,1);
if(num_class==1)
        num_class=2;
end

CodingMatrix=[]; 
max_iter=10000; %the upper limit of the number of times to randomly generate ternary column vector
counter=0; 

for iter=1:max_iter
    if(mod(iter,100)==0)
        disp(['Coding matrix generation iteration: ',num2str(iter)]);
    end

    %generate one ternary column vector
    %Unlike in the paper, '+1' represents positive class, '-1' represents neutral class and '0' represents negative class 
    randnum=randperm(num_class);
    desert_dot=randnum(1:desert_num);
    tmpcode=zeros(num_class,1);
    pos_dot=randnum(desert_num+1:int32((num_class-desert_num)/2+desert_num));
    
    tmpcode(desert_dot)=-1;
    tmpcode(pos_dot)=1;
    
    pos_dot=tmpcode==1;
    neg_dot=tmpcode==0;
    desert_dot=tmpcode==-1;
    
    % derive the binary training set
    pos_dot(desert_dot)=1;
    neg_dot(desert_dot)=1;
    tmp_pos_idx=[]; 
    tmp_neg_idx=[];
    for i=1:num_train
        if ((train_target(:,i) & pos_dot)==train_target(:,i))&(sum(train_target(:,i))~=sum(train_target(desert_dot,i)))
            tmp_pos_idx=[tmp_pos_idx,i];
        else
            if((train_target(:,i) & neg_dot) == train_target(:,i))&(sum(train_target(:,i))~=sum(train_target(desert_dot,i)))
                tmp_neg_idx=[tmp_neg_idx,i];
            end
        end
    end

    % measure whether the number of examples in the derived binary training set is higher than the lower limit of quantity
    num_pos=length(tmp_pos_idx);
    num_neg=length(tmp_neg_idx);
    if((num_pos+num_neg>=thr)&&(num_pos>=5)&&(num_neg>=5))
        counter=counter+1;
        tr_pos_idx{counter,1}=tmp_pos_idx;
        tr_neg_idx{counter,1}=tmp_neg_idx;
        CodingMatrix=[CodingMatrix,tmpcode];
    end
    
    if(counter==CodewordLength)
        break;
    end
end

if(counter~=CodewordLength)
    disp(['The required codeword length ',num2str(CodewordLength),' not satisfied']);
    CodewordLength=counter;
    if(counter==0)
        error('Empty coding matrix');
    end
end

% train and save binary classifiers
baseModels=cell(CodewordLength,1); 
parfor k=1:CodewordLength

    pos_inst=train_data(tr_pos_idx{k,1},:);
    neg_inst=train_data(tr_neg_idx{k,1},:);
      
    training_instance_matrix=[pos_inst;neg_inst]; 
    training_label_vector=[ones(length(tr_pos_idx{k,1}),1);zeros(length(tr_neg_idx{k,1}),1)]; 
    %baseModel = libsvmtrain(training_label_vector, training_instance_matrix , str);
    SVMModel = fitcsvm(training_instance_matrix,training_label_vector, 'KernelFunction', 'linear', 'Standardize', true);
    baseModels{k,1}=SVMModel;
end

%calculate the performance matrix
performanceMatrix=zeros(num_class,CodewordLength);
parfor j=1:CodewordLength

    baseModel = baseModels{j,1};
    
    testing_label_vector=ones(num_train,1);
    %[predicted_label, accuracy, decision_values] = libsvmpredict(testing_label_vector, train_data, baseModel);
    [predicted_label, score] = predict(baseModel, train_data);


    for i=1:num_class
        labelClass_i = predicted_label(train_target(i,:)==1,:);
        performanceMatrix(i,j) = sum(labelClass_i==CodingMatrix(i,j))/size(labelClass_i,1);
    end
end

% save the model
sumMatrix = repmat(sum(performanceMatrix,2),1,CodewordLength);
model.performanceMatrix = performanceMatrix./sumMatrix;
model.baseModels = baseModels;
model.CodewordLength =CodewordLength;
model.CodingMatrix = CodingMatrix;
end

