function [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,MicroF1,MacroF1,Pre_Labels,outputValue] = PAMB_predict(test_data,test_target,model)

% PAMB_predict makes prediction for testing data by adapted loss-weighted decoding strategy.
% 
% Syntax
%     [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,MicroF1,Pre_Labels,outputValue] = PAMB_predict(test_data,test_target,model)
%
% Description
%     PAMB_predict takes,
%         test_data              - A num_test x num_fea array, the ith instance of testing instance is stored in test_data(i,:).
%         test_target            - A num_calss x num_test array, if the jth class label is one of the ground-truth labels for the ith testing instance, then test_target(j,i) equals to 1, otherwise 0.
%         model                  - The set of derived binary classifiers and the performance matrix.
%     and returns
%         HammingLoss            - Experimental results in terms of hamming loss on testing data
%         RankingLoss            - Experimental results in terms of ranking loss on testing data
%         OneError               - Experimental results in terms of one-error on testing data
%         Coverage               - Experimental results in terms of coverage on testing data
%         Average_Precision      - Experimental results in terms of average precision on testing data
%         MicroF1                - Experimental results in terms of microF1 on testing data
%         PreLabels              - A num_class x num_test array, if PAMB predicts that the jth class label is one of ground-truth labels for the ith instance, PreLabels(j,i) equals to 1, otherwise 0.
%         outputValue            - A num_class x num_test array, outputValue(j,i) represents the final scores of the ith instance on the jth class label. 


Bin_Pre=[];
value = [];

performanceMatrix = model.performanceMatrix ;
baseModels = model.baseModels ;
CodingMatrix = model.CodingMatrix ;
CodewordLength = model.CodewordLength;
[num_class,num_test] = size(test_target);

% binary classifiers make prediction on testing data
parfor k=1:CodewordLength
    model=baseModels{k,1};
    testing_label_vector=ones(num_test,1);
	[predicted_label, decision_values] = predict(model,test_data);
    %[predicted_label, accuracy, decision_values] = libsvmpredict(testing_label_vector, test_data, model);
    Bin_Pre=[Bin_Pre,predicted_label];
    value = [value,decision_values(:,2)];
end

% loss-weighted decoding strategy
outputValue=zeros(num_class,num_test);
for i=1:num_test
    bin_pre_tmp = Bin_Pre(i,:); 
    decisionValue = value(i,:);
    for j=1:num_class
        codej = CodingMatrix(j,:);
        common = (bin_pre_tmp==codej).*performanceMatrix(j,:)./exp(abs(decisionValue));
        errors = (bin_pre_tmp~=codej).*performanceMatrix(j,:).*exp(abs(decisionValue));
        outputValue(j,i)=-sum(common)-sum(errors);
    end
end

% min-max normalization
outputValue=outputValue';
for i=1:num_test
    outputValue(i,:)=(outputValue(i,:)-min(min(outputValue(i,:))))/(max(max(outputValue(i,:)))-min(min(outputValue(i,:))));
end
Outputs=outputValue';

% divide relevant labels and irrelevant labels by a threshold (default 0.9)
Pre_Labels=zeros(num_class,num_test);
for i=1:num_test
    for j=1:num_class
        if(Outputs(j,i)>0.9)
            Pre_Labels(j,i)=1;
        else
            Pre_Labels(j,i)=0;
        end
    end
end

% calculate the experimental results in terms of six evaluation metrics
HammingLoss=Hamming_loss(Pre_Labels,test_target);
OneError=One_error(Outputs,test_target);
RankingLoss=Ranking_loss(Outputs,test_target);
Coverage=coverage(Outputs,test_target);
Average_Precision=Average_precision(Outputs,test_target);
MicroF1=mi_F1(Pre_Labels,test_target);
MacroF1=ma_F1(Pre_Labels,test_target);


end
