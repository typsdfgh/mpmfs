
clc
clear
addpath(genpath(pwd));

datasets = { 'HumanPseAAC','corel5k'};
%datasets = { 'birds','corel5k','llog_f', 'CAL500','CHD_49','yeast', 'water','HumanPseAAC','PlantPseAAC'};
n_fold = 5;
cl_columns = {'dataset','method','classifier','fs_num','k_no', 'AP_mi','HL', 'F1_ma', 'F1_mi','ONE','CE', 'RL','lambda1','lambda2'};

% 初始化记录文件
dataStruct = struct();
for i = 1:length(cl_columns)
    dataStruct.(cl_columns{i}) = [];
end
cl_result_record({}, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pamb\PAMB14.csv', dataStruct, 1);
cl_result_record({}, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pamb\PAMB24.csv', dataStruct, 1);

% 遍历每一个
for dataN = 1:2
    % load data
    Dataset = datasets{dataN};
    disp(Dataset);
    path = ['D:\Doc\PML-PYTHON\make_data\data/',Dataset,'.mat'];
    path =join(path, '');
    load(path);
    % preprocess
    n_sample = size(data, 1);
    data = normalize(data);
	
	% data,label,partial都是行是样本，列是特征
    % n_fold validation and evaluation
    for i = 1:n_fold-1
        fprintf('Data processing, Cross validation: %d\n', i);
        % split data
		[x_train, x_test, y_train, y_test, l_train, l_test] = split_data_fold(double(data), target', partial_labels', i, n_fold);
		[train_data, test_data, train_target, test_target, train_p_target, l_test] = remove_uniform_labels(x_train, x_test, y_train, y_test, l_train, l_test);
		
        % setup parameters for LE model
        desert_num=2; % the number of '0' in the ternary coding vector
		multiLength=100; % the coefficient of CodewordLength
		thr = ceil(0.01 * size(train_data,1)); % lower bound of sample size of the derived binary training set
        CodewordLength = round(multiLength * log2(size(train_p_target,1))); % the number of columns of coding matrix
        gamma = 1;
        str=strcat(' -t 2 -g',32,num2str(gamma),' -q'); % parameters in libsvm, we use RBF kernel for better noise-resisting ability
		
		
		% train a multi-label classifier
        model = PAMB_train(train_data,train_p_target',CodewordLength,thr,str,desert_num);
        
        % predict on testing data
        [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,MicroF1,MacroF1,Pre_Labels,outputValue] = PAMB_predict(test_data,test_target',model);
		
		classification_result = struct();
		classification_result.dataset = Dataset;
		classification_result.method = 'PAMB';
		classification_result.classifier = 'XW';
		classification_result.fs_num = 0;
		classification_result.k_no = i;
		classification_result.AP_mi = Average_Precision;
		classification_result.HL = HammingLoss;
		classification_result.F1_ma = MacroF1;
		classification_result.F1_mi = MicroF1;
		classification_result.ONE = OneError;
		classification_result.CE = Coverage;  
		classification_result.RL = RankingLoss;
		classification_result.desert_num = 2;
		classification_result.multiLength=100;
        cl_result_record(classification_result, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pamb\PAMB24.csv', cl_columns, 0);
		
		
		% 获取参数矩阵W，
		W = get_W_process(test_data, Pre_Labels') ;
		W_2 = sqrt(sum(W.^2, 2));
		[~, f_idx] = sort(W_2, 'descend');
		f_idx = f_idx.';
		if size(train_data, 2) > 100
			select_num = round(size(train_data, 2) * 0.2);
			select_num_list = round(select_num * (1:20) / 20);
        elseif size(train_data, 2) < 20
                    select_num_list = 1:size(train_data, 2);
		else
			select_num_list = 1:20;
		end

		for num = select_num_list
			data_test = test_data(:, f_idx(1:num));
			y_prob = data_test* W(f_idx(1:num),:);
            y_pred=ones(size(y_prob));
            y_pred(y_prob < 0.5)= -1;
			test_target(test_target == 0) = -1;
			
			classification_result = struct();
			classification_result.dataset = Dataset;
			classification_result.method = 'PAMB';
			classification_result.classifier = 'XW';
			classification_result.fs_num = num;
			classification_result.k_no = i;
			classification_result.AP_mi = Average_precision(y_prob',test_target');
			classification_result.HL = Hamming_loss(y_pred',test_target');
			classification_result.F1_ma = ma_F1(y_pred',test_target');
			classification_result.F1_mi = mi_F1(y_pred',test_target');
			classification_result.ONE = One_error(y_prob',test_target');
			classification_result.CE = coverage(y_prob',test_target');  
			classification_result.RL = Ranking_loss(y_prob',test_target');
			classification_result.desert_num = 2;
			classification_result.multiLength=100;
            cl_result_record(classification_result, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pamb\PAMB14.csv', cl_columns, 0);
		end
		
    end
end
