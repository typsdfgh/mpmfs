% MATLAB 代码示例

% 定义参数矩阵X和Y以及对应的评价指标矩阵Z
X = 1:10; % 假设X参数从1到10
Y = 1:5;  % 假设Y参数从1到5
Z = 1:5;
[Z, Xgrid, Ygrid] = meshgrid(1:5, 1:10, 1:10); % 创建一个10x5的Z矩阵

% 随机填充Z矩阵
Z = rand(10, 5) * 100; % 随机生成评价指标值

% 创建三维柱状图
figure;
bar3(Z); % 使用bar3绘制三维柱状图
xlabel('X Parameter');
ylabel('Y Parameter');
zlabel('Performance Metric');

% 标题
title('3D Bar Chart of Parameter Sensitivity Analysis');

% 调整视角
view(-60, 30); % 设置视角为更优展示三维柱状图

% 可选：调整颜色和颜色条
colormap(jet); % 使用jet颜色映射
colorbar; % 显示颜色条
