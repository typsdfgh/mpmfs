# PAMB
This repository is the official implementation of the paper 
“Bing-Qing Liu, Bin-Bin Jia, Min-Ling Zhang. Towards Enabling Binary Decomposition for Partial Multi-Label Learning. IEEE Transactions on Pattern Analysis and Machine Intelligence, in press.”

***

## Requirements
- MATLAB 2021a 
- Statistics and Machine Learning Toolbox  12.1
- Parallel Computing Toolbox  7.4
- Libsvm  3.24
***

To start, create a directory of your choice and copy the code there. 

Set the path in your MATLAB to add the directory you just created.

## Run
This repository provides one demo on the synthetic PML dataset **emotions3** to show the training and testing phase of the PAMB. You can run **"main.m"** to do it. 

Other real-word PML datasets is available from [PALM](http://palm.seu.edu.cn/zhangml/Resources.htm#data) and multi-label datasets can refer to [Mulan](http://mulan.sourceforge.net/datasets.html).