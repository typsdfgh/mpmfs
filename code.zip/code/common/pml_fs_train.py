"""
pml_fs_lc的训练函数
"""
import numpy as np

def optimModel(train_data, train_target, conf, par):
    [num_train, dim] = train_data.shape
    num_class = train_target.shape[0]

    Y = []
    Ybar = []
    gamma = []
    for i in range(num_train):
        Y.append(np.sum(train_target[:,i] == 1))
        Ybar.append(num_class - Y[i])
        gamma.append([1 /(Y[i] * Ybar[i]), 1 /(Y[i] * Y[i])])

    Y = np.array(Y)
    Ybar = np.array(Ybar)
    gamma = np.array(gamma)

    tol = par['tol']
    max_iter = par['max_iter']
    w = np.zeros((dim, num_class))
    b = np.zeros(num_class)

    Eps = []
    xwb = np.dot(train_data, w)
    num_list = np.zeros((2, num_class))
    for j in range(num_class):
        xwb[:,j] = xwb[:,j] + b[j]
        a = Ybar[train_target[j,:] == 1]
        b = Y[train_target[j,:] == -1]
        c = Y[train_target[j,:] == 1]
        num_list[0, j] = np.sum(a) + np.sum(b) + 2 * np.sum(c)
        Eps.append(np.zeros((np.sum(a) + np.sum(b) + 2 * np.sum(c),1)))



    print('Finish optimModel')

def fs_lc_train(Xtr, Yp, conf, correlation, prototype, par):
    max_iter = 10
    tol = 1e-4
    convergence = np.zeros((1, max_iter))
    iteration = 0
    while True:
        iteration += 1
        optimModel(Xtr, Yp, conf, par)