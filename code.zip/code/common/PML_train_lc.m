function [ trained_w, trained_b] = PML_train_lc( Xtr,Yp,conf,correlation,prototype)

%PML deals with partial multi-label learning problems
%    Note: 
%    1. It is necessary to install mosek at first. (https://www.mosek.com/)
%    2. Please enlarge the parameter(eg,C2 and C3) searching space if you fail %       to obtain promising results as shown in the paper. 
%    Syntax
%
%     [ trained_w, trained_b ] = PML_train( Xtr,Yp,conf,correlation,prototype,par)
%
%    Description
%
%       PML_train takes,
%           Xtr     - An MxN matrix, the ith instance of training instance is stored in train_data(i,:)
%           Yp     - A QxM matrix, if the jth class label is one of the partial labels(not ground-truth) for the ith training instance, 
%                                  then train_label(j,i) equals +1, otherwise train_label(j,i) equals  -1
%           correlation     - An QxQ matrix, the correlation between ith label and jth label is stored in S(i,j);
%           prototype      - An QxN matrix,  the feature prototype of ith class label is stored in Q(i,:);
%           par                - parameters of C2 and C3, max_iter and tol
%
%      and returns,
%           trained_w      - trained weight of the model
%           trained_b       - trained bias of the model

%读取par，从python par 转为matlab par：
load('.\\saved_struct_fs_lc.mat');

max_iter = 10;
tol = 1e-4;
convergence = zeros(1,max_iter);
iteration = 0;
while true
    iteration = iteration+1;
    [ trained_w,trained_b,Eps,wbLoss] = optimModel(Xtr,Yp,conf,par);
    [ conf,confLoss] = optimConf_lc(conf,Xtr,Yp,Eps,correlation,prototype,par);
    convergence(iteration) = wbLoss+confLoss;
    
    fprintf('iteration: %d loss: %.3f\n',iteration, convergence(iteration));
    if iteration>1
        if abs(convergence(iteration) - convergence(iteration-1)) <= tol*abs(convergence(iteration))
%             fprintf('optimization converge at ratio difference %f\n',tol);
            break
        end
    end
    if iteration>max_iter
        fprintf('exceed maximum iterations\n');
        break;
    end
end
%方法二：存储四个输出参数
save('.\\test_save_fslc_train_result.mat','trained_w','trained_b');
end

