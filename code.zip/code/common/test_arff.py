"""用原始arff文件读入，测试ML-KNN的方法"""


import scipy
import pandas as pd
import numpy as np
from scipy.io import arff
from sklearn.model_selection import train_test_split
from skmultilearn.adapt import MLkNN
from sklearn.metrics import accuracy_score
from skmultilearn.dataset import load_from_arff # 读取delicious

if __name__ == '__main__':
    print('start')
    # data, meta = scipy.io.arff.loadarff('.\\yeast-train.arff')
    #data, meta = scipy.io.arff.loadarff('.\\emotions.arff')
    dataset = [# 第一批
               '.\\data_arff\\CAL500.arff',
               '.\\data_arff\\birds-train.arff',
               '.\\data_arff\\birds-test.arff',
               '.\\data_arff\\yeast.arff',
               '.\\data_arff\\Corel5k.arff',
               '.\\data_arff\\delicious-test.arff',
              # 第二批
               '.\\data_arff\\enron.arff',
               '.\\data_arff\\flags.arff',
               '.\\data_arff\\mediamill.arff',
               '.\\data_arff\\LLOG-F.arff',
               #'.\\data_arff\\SLASHDOT-F.arff',
                '.\\data_arff\\3sources_inter3000_full.arff',
                '.\\data_arff\\water-quality-nom.arff',
                '.\\data_arff\\chess.arff',
                '.\\data_arff\\bibtex.arff',
               ]
    # general reading
    #data, meta = scipy.io.arff.loadarff(dataset[-1])
    #data1, meta1 = scipy.io.arff.loadarff(dataset[2])

    #读取delicious
    label_count = 159
    X, y = load_from_arff(dataset[-1], label_count=label_count, label_location='end',input_feature_type='float',encode_nominal=False,load_sparse=False,return_attribute_definitions=False)
    X = X.todense()
    y = y.todense()
    X = X.A
    y = y.A
    high_threshold = min(label_count,15)
    #y = y[:,:high_threshold]
    # 选择15列不全为0的
    y = y.astype(np.float64)
    yt = np.transpose(y)

    count = 0
    row = yt.shape[0]
    result_index = []
    for i in range(label_count):
        temp = yt[i]
        if len(result_index) == high_threshold:
            break
        if not np.isin(temp, [0]).all():
           result_index.append(i)
    y = y[:, result_index]
    yt = np.transpose(y)
    #general process
    #df = pd.DataFrame(data)
    #df.head()

    #df1 = pd.DataFrame(data1)
    #df.head()
    #df2 = pd.concat([df,df1])

    # general process
    #X = df.iloc[:,0:500].values
    #y = df.iloc[:,499:].values

    # 针对corel5k &&delicious 选取15个label从374 && 个label中
    #y = df.iloc[:,500:515].values
    #X = X.astype(np.float64)


    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

    y_train = y_train.astype(np.float64)
    y_test = y_test.astype(np.float64)



    #birds删除第二行的yt（非1）
    #yt = np.delete(yt, 1, axis=0)
    #y = np.delete(y,1,axis=1)



    #确定存在有此label对应的instance
    count = 0
    row = yt.shape[0]
    ori_yt = yt.copy()
    for i in range(row):
        temp = ori_yt[i]
        if np.isin(temp,[0]).all():
            print(i,'需要替换此行')
            yt=np.delete(yt, i-count, axis=0)
            y=np.delete(y, i-count, axis=1)
            count += 1

    #确定存在有此instance对应的label
    count = 0
    for j in range(y.shape[0]):
        temp = y[j]
        if np.isin(temp,[0]).all():
            print(j,'删除该instance')
            yt = np.delete(yt, j-count, axis=1)
            X = np.delete(X, j - count, axis=0)
            count += 1





    #scipy.io.savemat('.\\CAL500.mat',{'data':X,'target':yt,'partial_labels':yt})
    #scipy.io.savemat('.\\birds.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\yeast.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\corel5k.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\delicious.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\enron.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\flags.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\mediamill.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\llog_f.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\3sources.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\water.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    #scipy.io.savemat('.\\chess.mat', {'data': X, 'target': yt, 'partial_labels': yt})
    scipy.io.savemat('.\\philosophy.mat', {'data': X, 'target': yt, 'partial_labels': yt})

    classifier = MLkNN()
    # train
    classifier.fit(X_train, y_train)
    # predict
    predictions = classifier.predict(X_test)

    # 连接matlab中的处理程序(入参字符串不可行)：


    print('Finish')