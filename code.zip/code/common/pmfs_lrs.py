import numpy as np
from numpy.random import seed
from numpy import linalg as LA
from scipy import linalg
from scipy.spatial import distance
from skfeature.utility.construct_W import construct_W
import skfeature.utility.entropy_estimators as ees
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
import scipy.io as scio
import scipy
import pandas as pd
import math
import pandas as pd
import skfeature.utility.entropy_estimators as ees
from sklearn.metrics.pairwise import cosine_similarity
import skfeature.utility.entropy_estimators as ees
import time
from sklearn.cluster import OPTICS
from sklearn.decomposition import NMF
from sklearn.datasets import make_blobs
eps = 2.2204e-16
import numpy as np

def diagonal_matrix_subtract(X, a):
    """
    输入:
    X: 对角矩阵 (numpy array 或类似数组的结构)
    a: 常数 (标量)
    
    输出:
    Y: 对角矩阵，其中 Y_ii = max(X_ii - a, 0)
    """
    # 确保X是一个对角矩阵（这里假设X是一个一维数组表示对角元素，或者是一个二维对角矩阵）
    if len(X.shape) == 1:
        diag = X
    else:
        diag = np.diag(X)
    
    # 计算新的对角元素
    new_diag = np.maximum(diag - a, 0)
    
    # 构造新的对角矩阵
    Y = np.diag(new_diag)
    
    return Y
def soft_threshold(a, v):
    """
    软阈值函数（标量或数组输入）
    
    参数:
        a : 输入值（标量或数组）
        v : 阈值（非负）
    
    返回:
        软阈值处理后的值
    """
    return np.sign(a) * np.maximum(np.abs(a) - v, 0)
def PMFS_LRS(X, Y,para1,para2,para3):
    time_start = time.time()
    n,d=X.shape
    n,l=Y.shape
    X_t=X.T
    Y_t=Y.T
    W = np.random.rand(d, l)
    R=Y_t
    S=np.zeros((l,n))
    one=np.ones((n,1))
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}
    S_ = construct_W(X, **options)
    S_ = S_.A
    A = np.diag(np.sum(S_, 0))
    I=np.eye(n)
    H=I-one@one.T/n
    L = A - S_
    t=0
    obji = 1
    fun_ite=[]
    para4=1e6
    
    L1=2*H + 2*L + para4*I
    L1_constant= np.linalg.norm(L1, ord='fro')
    cver=0
    while 1:
        Btmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)
        
        temp1=X_t@H@X_t.T+para3*D
        W=np.linalg.inv(temp1)@(X_t@H@R.T)
       
      
        
        Z=R-(1/L1_constant)*(2*(R-W.T@X_t)@H+2*R@L+para4*(R+S-Y_t))
        U, Sss, Vt = np.linalg.svd(Z, full_matrices=False)
        S2=diagonal_matrix_subtract(Sss,para1/L1_constant)
        R=U@S2@Vt
        S=soft_threshold(Y_t-R,para2/para4)


        Uu,ss,Vh=np.linalg.svd(R,full_matrices=False)
        R_nu=np.sum(ss)
        e=((R-W.T@X_t)@one)/n
        W21=np.sum(np.linalg.norm(W, axis=1, ord=2))
        S1=np.linalg.norm(A, ord=1)
        fun= pow(LA.norm(np.dot(W.T, X_t)+e*one.T-R, 'fro'), 2)+np.trace(np.dot(np.dot(R, L), R.T))+para1*R_nu+para2*S1+para3*W21+para4/2*pow(LA.norm(R+S-Y_t, 'fro'), 2)
        fun_ite.append(fun)
        cver = abs((fun - obji) / float(obji))
        obji = fun
        t=t+1
        print(fun,t)
        if (t > 2 and (cver < 1e-3 or t == 1000)):
            #W=np.dot(W,S)
            break
    time_end = time.time()
    running_time = time_end - time_start
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]

    return l, W
