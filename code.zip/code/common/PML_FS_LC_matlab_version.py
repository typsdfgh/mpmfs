
"""
18年huang的pml-fs && lc算法调用matlab
"""

import scipy.io as sio
from pml_fs_featureProtype import featureProtype
from pml_fs_labelRelation import labelRelation
from process_data import python_to_matlab_matrix, read_general_mat_data
from func_timeout import func_set_timeout
from sklearn import metrics
@func_set_timeout(60000)

def PML_FS_LC_process(Xtr, Ytr, Yp, conf, Xte, Yte, alg, eng):
    # 已转为python的部分
    #prototype = featureProtype(Xtr, Ytr)
    #correlation = labelRelation(Ytr)
    #[num_class, num_train] = Ytr.shape

    par = {'C2': 0.1, 'C3': 0.1, 'tol': 1e-4, 'max_iter': 10}
    sio.savemat('.\\saved_struct_fs_lc.mat', {'par': par})

    # 将python数据转为matlab入参：
    fslc_tr_data = python_to_matlab_matrix(Xtr, eng)
    fslc_yp_data = python_to_matlab_matrix(Yp, eng)
    fslc_conf = python_to_matlab_matrix(conf, eng)

    fslc_te_data = python_to_matlab_matrix(Xte, eng)
    fslc_ye_data = python_to_matlab_matrix(Yte, eng)
    fslc_yr_data = python_to_matlab_matrix(Ytr, eng)

    eng.featureProtype(fslc_tr_data, fslc_yr_data, nargout=0)
    eng.labelRelation(fslc_yr_data, nargout=0)
    # 读取数据集
    print("读取数据集---test_save_fslc_train_result.mat")
    temp_matrix_dict = read_general_mat_data('.\\test_save_fslc_featureProtype_result.mat')
    prototype = temp_matrix_dict['Q']
    temp_matrix_dict = read_general_mat_data('.\\test_save_fslc_corr_result.mat')
    correlation = temp_matrix_dict['S']

    fslc_corr = python_to_matlab_matrix(correlation, eng)
    fslc_prototype = python_to_matlab_matrix(prototype, eng)

    if alg == 'lc':
        print("+++++++++++++++lc算法分支")
        eng.PML_train_lc(fslc_tr_data, fslc_yp_data, fslc_conf, fslc_corr, fslc_prototype, nargout=0)
    elif alg == 'fs':
        print("+++++++++++++++fs算法分支")
        eng.PML_train_fs(fslc_tr_data, fslc_yp_data, fslc_conf, fslc_corr, fslc_prototype, nargout=0)
    else:
        print("alg输入有误")
        return
    # 读取数据集
    print("读取数据集---test_save_fslc_train_result.mat")
    matrix_dict_1 = read_general_mat_data('.\\test_save_fslc_train_result.mat')
    trained_w = matrix_dict_1['trained_w']
    trained_b = matrix_dict_1['trained_b']
    tw = python_to_matlab_matrix(trained_w, eng)
    tb = python_to_matlab_matrix(trained_b, eng)
    eng.PML_test(fslc_te_data, fslc_ye_data, fslc_yr_data, tw, tb, nargout=0)

    # 读取数据集
    print("读取数据集---test_save_fslc_test_result.mat")
    matrix_dict_2 = read_general_mat_data('.\\test_save_fslc_test_result.mat')
    HammingLoss = matrix_dict_2['HammingLoss']
    RankingLoss = matrix_dict_2['RankingLoss']
    OneError = matrix_dict_2['OneError']
    Coverage = matrix_dict_2['Coverage']
    Average_Precision = matrix_dict_2['Average_Precision']
    Outputs = matrix_dict_2['Outputs']
    Pre_Labels = matrix_dict_2['Pre_Labels']

    f1 = Pre_Labels.copy()
    f1[f1==-1] = 0
    f2 = Yte.copy()
    f2[f2==-1] = 0
    F1_micro = metrics.f1_score(f1, f2, labels=[0, 1], average='micro')
    F1_macro = metrics.f1_score(f1, f2, labels=[0, 1], average='macro')
    return HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro