function [RankingLosses,OneErrors,AveragePrecisions,Hamminglosses,coverages,p, Pre_Labels]=evaluate_IDEA2(predict_values, GroundTruth)

GroundTruth1=GroundTruth;
GroundTruth1(GroundTruth1==-1)=0;
% ======================Evaluation metrics=================================
RankingLoss= Ranking_loss(predict_values',GroundTruth1'); % 统一不再1-xxx
OneError= One_error(predict_values',GroundTruth1');% 统一不再1-xxx
Average_Precision= Average_precision(predict_values',GroundTruth1');

%补充两个：
%Evaluation% 每种方式的prelabel置1的算法设计不同，此种方式同mlknn，但0.5阈值不同
[num_class,num_testing]=size(predict_values');
Outputs=predict_values';
Pre_Labels=zeros(num_class,num_testing);
for i=1:num_testing
    for j=1:num_class
        if(Outputs(j,i)>=0.5)
            Pre_Labels(j,i)=1;
        else
            Pre_Labels(j,i)=0;
        end
    end
end
HammingLoss= Hamming_loss(Pre_Labels, GroundTruth1');% 统一不再1-xxx
Coverage = coverage(predict_values', GroundTruth1');% 统一不再1-xxx

save('.\\test_save_IDEA2_result.mat', 'HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision','Outputs','Pre_Labels');