"""
根据6个数据集选择了0.02-0.05
"""

# coding=UTF-8
import numpy as np
from skfeature.utility.construct_W import construct_W
from numpy import linalg as LA
from numpy.random import seed
import pandas as pd
import time
import os
from process_data import read_general_mat_data, write_to_csv_file
import func_timeout
from func_timeout import func_set_timeout
import matlab.engine
from process_data import python_to_matlab_matrix
from sklearn import metrics
eps = 2.2204e-16
@func_set_timeout(6000)


def discrete_3(X):
    """
    功能：数据集离散方法 分箱法(箱数=3)
    """
    sample_row, sample_colum = np.shape(X)
    for i in range(sample_colum):
        m = pd.cut(X[:, i], 3, labels=[0, 1, 2])
        for j in range(sample_row):
            X[j, i] = m[j]
    return X

def process_x_y(X,Y, temp_name):
    num, dim = X.shape
    num, label_num = Y.shape


    W = np.random.rand(dim, label_num)
    iter = 0
    obj = []
    obji = 1

    while 1:
        # l1范式
        Btmp = np.multiply(np.sum(np.sign(W),1), 2) + eps
        d1 = 1 / Btmp
        Q = np.diag(d1.flat)

        # L2范式
        #Btmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        #d1 = 0.5 / Btmp
        #Q = np.diag(d1.flat)


        temp1 = np.dot(X.T, Y)
        temp2 = np.dot(np.dot(X.T, X), W) + np.dot(Q, W) + eps

        W = np.multiply(W, np.true_divide(temp1, temp2))
        objectives = pow(LA.norm(np.dot(X,W) - Y, 'fro'), 2) + 2 * np.trace(np.dot(np.dot(W.T, Q), W))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break
    # 写入文件
    #pd_data = pd.DataFrame(W)
    #pd_data.to_csv(".//temp_result_w_idea1//test.csv", header=None, index=False)
    #pd_data.to_csv(temp_name, header=None, index=False)

    return W

def first_idea_process(X, Y, select_nub, alpha, beta, gamma, theta):
    num, dim = X.shape
    num, label_num = Y.shape
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}
    Sx = construct_W(X, **options)
    Sx = Sx.A
    Ax = np.diag(np.sum(Sx, 0))
    Lx = Ax - Sx

    k = int(np.ceil(dim * 0.8))

    seed(2)
    U = np.random.rand(num, k)
    V = np.random.rand(k, label_num)
    M = np.random.rand(k,dim)

    iter = 0
    obj = []
    obji = 1

    while 1:
        temp_v = np.dot(M.T, V)
        Btmp = np.sqrt(np.sum(np.multiply(temp_v, temp_v), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)

        V = np.multiply(V, np.true_divide(np.dot(np.dot(M, X.T), Y) + alpha * np.dot(U.T, Y),
                                          np.dot(np.dot(np.dot(M, X.T), X),temp_v) + alpha * np.dot(np.dot(U.T, U), V)  + theta*np.dot(np.dot(M,D),temp_v)+ eps))

        U = np.multiply(U, np.true_divide(alpha * np.dot(Y,V.T) + beta * np.dot(X, M.T) + gamma * np.dot(Sx, U), alpha*np.dot(np.dot(U, V),V.T) + beta*np.dot(np.dot(U, M), M.T) +  gamma * np.dot(Ax, U) +eps))

        M = np.multiply(M, np.true_divide(np.dot(V,np.dot(Y.T, X)) + beta * np.dot(U.T,X),
                                          np.dot(np.dot(np.dot(V, temp_v.T),X.T),X) + beta * np.dot(np.dot(U.T, U),M) + theta*np.dot(np.dot(np.dot(V,V.T), M),D)+eps))

        #test
        temp_v = np.dot(M.T, V)
        part1 = pow(LA.norm(np.dot(X,temp_v) - Y, 'fro'), 2)
        part2 = alpha * pow(LA.norm(Y - np.dot(U, V), 'fro'), 2)
        part5 = beta * pow(LA.norm(X - np.dot(U, M), 'fro'), 2)
        part3 = gamma * np.trace(np.dot(np.dot(U.T, Lx), U))
        part4 = 2 * theta * np.trace(np.dot(np.dot(temp_v.T, D), temp_v))
        objectives = part1 + part2 + part3 + part4 + part5

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break

    # test:
    score = np.sum(np.multiply(temp_v, temp_v), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]
    l_new = np.array(l[:select_nub])
    remove_col = np.setdiff1d(np.arange(X.shape[1]), l_new)

    new_W = temp_v.copy()
    new_W[remove_col, :] = np.zeros(label_num)

    return new_W
    #return temp_v

    """
    
    obj_value = np.array(obj)
    obj_function_value = []
    for i in range(iter):
        temp_value = float(obj_value[i])
        obj_function_value.append(temp_value)
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    l = [i for i in idx]
    n = 1
    F = [l[i:i + n] for i in range(0, len(l), n)]
    F = np.matrix(F)

    ll = [i for i in obj_function_value]
    n = 1
    F_value = [ll[i:i + n] for i in range(0, len(ll), n)]
    F_value = np.matrix(F_value)
    return F[0:select_nub, :], F_value[:, :], iter
    """

def evaluate(Xte, W, ori_Y, eng):
    Outputs = np.dot(Xte, W)
    Outputs = python_to_matlab_matrix(Outputs, eng)
    Y = python_to_matlab_matrix(ori_Y, eng)
    eng.evaluate_IDEA2(Outputs, Y, nargout=0)
    # 读取数据集
    #print("读取数据集---test_save_IDEA2_result.mat")
    matrix_dict_2 = read_general_mat_data('.\\test_save_IDEA2_result.mat')
    HammingLoss = matrix_dict_2['HammingLoss']
    RankingLoss = matrix_dict_2['RankingLoss']
    OneError = matrix_dict_2['OneError']
    Coverage = matrix_dict_2['Coverage']
    Average_Precision = matrix_dict_2['Average_Precision']
    Outputs = matrix_dict_2['Outputs']
    Pre_Labels = matrix_dict_2['Pre_Labels']

    F1_micro = metrics.f1_score(ori_Y.T, Pre_Labels, labels=[0, 1], average='micro')
    F1_macro = metrics.f1_score(ori_Y.T, Pre_Labels, labels=[0, 1], average='macro')

    #F1_micro = metrics.f1_score(Pre_Labels, ori_Y.T, labels=[0, 1], average='micro')
    #F1_macro = metrics.f1_score(Pre_Labels,ori_Y.T, labels=[0, 1], average='macro')

    return HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro




if __name__ == "__main__":
    print("START-IDEA1")
    # 测试数据集.\\emotions_partial_4.mat(593,72)
    data_set = [  # 成功数据集
        '.\\data\\pml_mirflickr\\mirflickr.mat',
        '.\\data\\pml_YeastMF\\YeastMF.mat',
        '.\\data\\pml_music_emotion\\music_emotion.mat',
        '.\\data\\test\\emotions_partial_4.mat',  # (593,72,6),源自pml-fs-lc
        #'.\\make_data\\CAL\\CAL500.mat',
        #'.\\make_data\\Birds\\birds.mat',
        #'.\\make_data\\Yeast\\yeast.mat',
        '.\\make_data\\Corel5k\\corel5k.mat',
        '.\\make_data\\Delicious\\delicious.mat',

        #'.\\make_data\\Enron\\enron.mat',
        #'.\\make_data\\Flags\\flags.mat',

        '.\\make_data\\Mediamill\\mediamill.mat',
        '.\\make_data\\LLOG_F\\llog_f.mat',
        '.\\make_data\\3source\\3sources.mat',
        '.\\make_data\\Water\\water.mat',
        '.\\make_data\\Chess\\chess.mat',
        '.\\make_data\\Bibtex\\bibtex.mat',

    ]

    # 测试运行时间，可以分为train or test or all，此处暂做python示例，对于fpml未拆分的，可以从matlab作计时。
    # 但本文算法暂用python，对比环境与其它算法不一致（隐患），考虑此维度需慎重。
    for dd in range(1, 2):
    #for dd in range(0, 1):
    # for dd in range(len(data_set)-1,len(data_set)):
        d = data_set[dd]
        # 运行每个数据集总时间：
        s_time = time.time()
        # 读取数据集
        print("读取数据集---" + d)
        matr1 = read_general_mat_data(d)
        ori_data = matr1['data']
        target = matr1['target']
        #partial_labels = matr1['partial_labels']  # 测试数据集：partial_labels,candidate_labels
        partial_labels = matr1['candidate_labels']
        # 确定存在有此label对应的instance(eg-birds.mat未处理干净)
        count = 0
        row = target.shape[0]
        for i in range(row):
            temp = target[i]
            if np.isin(temp, [0]).all() or np.isin(temp, [1]).all():
                print(i, '需要替换此行')
                target = np.delete(target, i - count, axis=0)
                partial_labels = np.delete(partial_labels, i - count, axis=0)
                count += 1

        # 确定存在有此instance对应的label
        count = 0
        y = target.T
        for j in range(y.shape[0]):
            temp = y[j]
            if np.isin(temp, [0]).all() or np.isin(temp, [1]).all():
                #print(j, '删除该instance')
                target = np.delete(target, j - count, axis=1)
                ori_data = np.delete(ori_data, j - count, axis=0)
                partial_labels = np.delete(partial_labels, j - count, axis=1)
                count += 1


        # 预处理try to get label为0的列
        ddd = d.split('\\')[2]
        temp_name = './/temp_result_w_idea1//' + ddd + '.csv'

        temp_nega = np.where(ori_data < 0)
        if len(temp_nega[0]):
            positive_data = discrete_3(ori_data)
            print(ddd + '数据集存在负值！')
        else:
            positive_data = ori_data.copy()

        p_labels = partial_labels.T

        p_labels = p_labels.astype(np.int8)
        p_labels[p_labels == -1] = 0

        t_labels = target.astype(np.int8)
        t_labels[t_labels == -1] = 0

        ori_W = process_x_y(positive_data, p_labels, temp_name)


        # 处理原始Y MATRIX
        low_threshold = [
            #0.01,
            0.02,
            #0.05
        ]
        high_threshold = 0.3
        percent = [
                   #0.01,
                   #0.02,
                   0.05
                        ]
        feature, label = ori_W.shape
        for low in low_threshold:
            W = ori_W.copy()
            W = np.where(W > low, W, 0)
            zero_array = np.where(W, 0, 1)
            zero_count = np.sum(zero_array, axis=0)
            zero_percent = np.divide(zero_count, feature)

            for p in percent:
                delete_count = 0
                new_target = t_labels.copy()
                new_partial_labels = p_labels.T.copy()
                data = positive_data.copy()
                """
                for z in range(len(zero_percent)):
                    if zero_percent[z] > (1 - p) and np.max(W[:, z:z + 1]) < high_threshold:
                        new_partial_labels = np.delete(new_partial_labels, z - delete_count, axis=1)
                        new_target = np.delete(new_target, z-delete_count, axis=0)
                        delete_count += 1
                        print('存在删除')


                # 确定存在有此instance对应的label， ranking——loss不能接受label_size有0
                new_partial_labels = new_partial_labels.T
                count = 0
                y = new_target.T
                for j in range(y.shape[0]):
                    temp = y[j]
                    if np.isin(temp, [0]).all():
                        #print(j, '删除该instance')
                        new_target = np.delete(new_target, j - count, axis=1)
                        data = np.delete(data, j - count, axis=0)
                        new_partial_labels = np.delete(new_partial_labels, j - count, axis=1)
                        count += 1
"""
                # 切分数据集
                print("###########################################")
                print("切分数据集---" + d)
                m = new_target.shape[1]
                if m == 0:
                    continue
                num_eps = 20

                # 方法二：十折
                prelab = np.array([])
                nfold = 10
                n_test = round(m / nfold)
                IDEA2_result = []
                for i in range(nfold):
                    print("第",i,"次fold:")
                    start_ind = i * n_test
                    if (start_ind + n_test) > m:
                        testI = np.arange(start_ind, m)
                    else:
                        testI = np.arange(start_ind, (start_ind + n_test))
                    trainI = np.setdiff1d(np.arange(m), testI)

                    Xtr = data[trainI, :]
                    Yp = new_partial_labels[:,trainI]
                    Ytr = new_target[:,trainI]

                    Xte = data[testI, :]
                    Yte = new_target[:, testI]
                    Ypte = new_partial_labels[:, testI]


                    try:
                        print("start_alg:")
                        num = int(np.ceil(Xtr.shape[1] * 0.2))
                        W1 = first_idea_process(Xtr, Ytr.T, select_nub=num, alpha=0.1, beta=0.1, gamma=0.3, theta = 0.1)
                        eng = matlab.engine.start_matlab()
                        HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro  = evaluate(Xte, W1, Yte.T, eng)
                        IDEA2_result.append(
                        [HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0], F1_micro, F1_macro])
                    except func_timeout.exceptions.FunctionTimedOut:
                        print('数据集', d, '跳过pml_lc')

                # 将10次写入csv文件：
                dd = d.split('\\')[2]
                if not os.path.exists('.//IDEA1_对比idea3-0518//' + dd):
                    os.makedirs('.//IDEA1_对比idea3-0518//' + dd)

                dir = './/IDEA1_对比idea3-0518//' + dd
                print('dir:', dir)

                write_to_csv_file(dir + './/IDEA1_result_' +str(low)+ '_'+str(p) +'.csv', IDEA2_result)
                print('finish once alg_'+dd+ '_'  +str(low)+ '_'+str(p))

        print("IDEA2 ALL DONE")

