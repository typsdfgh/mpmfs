function [HammingLoss,RankingLoss,OneError,Coverage,Average_Precision,Outputs,Pre_Labels] = ...
    PML_test(test_data,test_target,train_target,trained_w,trained_b)

num_train = size(train_target,2);
num_test = size(test_target,2);
average = ceil(sum(sum(train_target == 1))/num_train);
num_class = size(test_target,1);
test_xwb = test_data * trained_w;
for i = 1:num_class
    test_xwb(:,i) = test_xwb(:,i) + trained_b(1,i);
end

Pre_Labels = -1*ones(size(test_xwb));

for i=1:num_test
    [a,b] = sort(test_xwb(i,:),'descend');
    Pre_Labels(i,b(1:average)) = 1;
end

Pre_Labels = Pre_Labels';
Outputs = test_xwb';

HammingLoss=Hamming_loss(Pre_Labels,test_target);
RankingLoss=Ranking_loss(Outputs,test_target);
OneError=One_error(Outputs,test_target);
Coverage=coverage(Outputs,test_target);
Average_Precision=Average_precision(Outputs,test_target);

save('.\\test_save_fslc_test_result.mat', 'HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision', 'Outputs' ,'Pre_Labels')
end