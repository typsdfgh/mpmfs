function [Y_final, W] =fPML_train(X,Y,lamda1, lamda2, lamda3, k)
X=double(X)
Y=double(Y)
options = [];
options.maxIter =500;
options.lamda1 = lamda1;
options.lamda2 = lamda2;
options.lamda3 = lamda3;
options.K=k;
[~,mLabel]=size(Y);
[~,mFeature]=size(X);
% W = abs(rand(mFeature,mLabel));

X1=cell(1,mLabel);
Y1=cell(1,mLabel);
for i=1:mLabel
%     X1{i}=X;
    X1{i} = [X ones(size(X, 1), 1)]; % add bias.
end
for i=1:mLabel
    Y1{i}=Y(:,i);
end
[W, funcVal] = Least_Lasso(X1, Y1, lamda3/(2*lamda2));  % refer to the  Reference [1] and [2].
Xt=[X ones(size(X,1),1)];
F1=W'*Xt';
% maxIter=2;

% for i=1:maxIter
    [S, F, G, iterValue] = UpdateGSF(X',Y', F1, options);
    [W, funcVal] = UpdateW(X, Y, S, G, options);
% end

Y_final=S*G';
Y_final=Y_final';

end

%  Reference:
% [1] Tibshirani, J. Regression shrinkage and selection via  the Lasso, Journal of the Royal Statistical Society. Series B 1996
% [2] Jiayu Zhou, Jianhui Chen, Jieping Ye, MALSAR: Multi-tAsk Learning via  StructurAl Regularization, 2012. 
         %  code can be found in   https://github.com/jiayuzhou/MALSAR





