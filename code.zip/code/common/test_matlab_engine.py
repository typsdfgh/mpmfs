"""
【PML】python调用matlab版的主函数
"""
import os
import time
import matlab.engine
import numpy as np
import eventlet  # 导入eventlet这个模块
import func_timeout
from process_data import read_general_mat_data, write_to_csv_file, process_mean, get_W_process,delete_zero
from MLKNN_matlab_version import ML_KNN_process
from PML_FS_LC_matlab_version import PML_FS_LC_process
from PML_fPML_matlab_version import fPML_process
from PML_Partical_matlab_version import PML_Partical_process, PML_Partical_alg_result
from tnnls_process import SSFS
from IDEA1 import evaluate
from MIFS_process import MIFS
from IDEA2 import discrete_3
from SCMFS import SCMFS
from DRMFS import DRMFS

default_root = r'G:\偏多标签学习\exp-paper\mll_practice_coding\PML-PYTHON'





if __name__ == '__main__':
    print("START")
    # 测试数据集.\\emotions_partial_4.mat(593,72)
    data_set = [#成功数据集
                #'.\\data\\test\\emotions_partial_4.mat', #(593,72,6),源自pml-fs-lc
                # zml-pml数据集
                '.\\data\\pml_mirflickr\\mirflickr.mat', #(10433,100,7)
                '.\\data\\pml_music_emotion\\music_emotion.mat',#(6833,98,11)
                #'.\\data\\pml_music_style\\music_style.mat',#(6839,98,10)
                #'.\\data\\pml_YeastBP\\YeastBP.mat', #(6139,6139,217)
                #'.\\data\\pml_YeastCC\\YeastCC.mat', #(6139,6139,50)
                '.\\data\\pml_YeastMF\\YeastMF.mat', #(6139,6139,39)

                #'.\\split_data\\s1_music_emotion\\music_emotion.mat',

                '.\\make_data\\CAL\\CAL500.mat',
                '.\\make_data\\Birds\\birds.mat',
                '.\\make_data\\Yeast\\yeast.mat',
                '.\\make_data\\Corel5k\\corel5k.mat',
                '.\\make_data\\Delicious\\delicious.mat',

                '.\\make_data\\Enron\\enron.mat',
                '.\\make_data\\Flags\\flags.mat',

                '.\\make_data\\Mediamill\\mediamill.mat',
                '.\\make_data\\LLOG_F\\llog_f.mat',
                '.\\make_data\\3source\\3sources.mat',
                '.\\make_data\\Water\\water.mat',
                '.\\make_data\\Chess\\chess.mat',
                '.\\make_data\\Bibtex\\bibtex.mat',
                ]



    # 测试运行时间，可以分为train or test or all，此处暂做python示例，对于fpml未拆分的，可以从matlab作计时。
    # 但本文算法暂用python，对比环境与其它算法不一致（隐患），考虑此维度需慎重。
    data_count = 0 # 用于保存w文件名称
    #for dd in range(len(data_set)):
    for dd in range(2,3):
    #for dd in range(len(data_set)-6,len(data_set)-5):
        d = data_set[dd]
        dd = d.split('\\')[2]
        if not os.path.exists('.//temp_compare_W//' + dd):
            os.makedirs('.//temp_compare_W//' + dd)

        dir_W = './/temp_compare_W//' + dd
        print('W-dir:', dir_W)

        # 运行每个数据集总时间：
        s_time = time.time()
        # 读取数据集
        print("读取数据集---"+d)
        matr1 = read_general_mat_data(d)
        ori_data = matr1['data']
        target = matr1['target']
        partial_labels = matr1['candidate_labels'] #测试数据集：partial_labels,candidate_labels

        target, partial_labels, ori_data,_,_ = delete_zero(target, partial_labels, ori_data)

        mul_Y_p = partial_labels.copy()
        mul_Y_p[mul_Y_p == -1] = 0

        mul_Y = target.copy()
        mul_Y[mul_Y == -1] = 0

        temp_nega = np.where(ori_data<0)
        if len(temp_nega[0]):
            data = discrete_3(ori_data)
            # test
            #new_data = data.copy()
            print(d+'数据集存在负值！')
        else:
            data = ori_data.copy()

        # 切分数据集
        print("###########################################")
        print("切分数据集---"+d)
        m = target.shape[1]
        num_eps = 20

        #方法一：随机
        #np.random.seed(1)
        #trainI = np.random.choice(m - 1, math.floor(m * 0.8), replace=False)
        #testI = np.setdiff1d(np.arange(m), trainI)
        # 测试对比matlab版：
        #trainI = np.arange(0, math.floor(m * 0.8))
        #testI = np.arange(math.floor(m * 0.8), m)
        mlknn_result_pl = []
        mlknn_result = []
        pml_lc_result = []
        pml_fs_result = []
        fpml_result = []
        SSFS_result = []
        MIFS_result = []
        SCMFS_result = []
        DRMFS_result = []
        mark = 0
        par_mark = 0
        #方法二：十折
        prelab = np.array([])
        nfold = 10
        n_test = round(m/nfold)
        for i in range(nfold):
            #test
            #i = 6
            print("第",i,"次fold：")
            start_ind = i * n_test
            if (start_ind+n_test) > m:
                testI = np.arange(start_ind, m)
            else:
                testI = np.arange(start_ind,(start_ind+n_test))
            trainI = np.setdiff1d(np.arange(m), testI)

            Xtr = data[trainI, :]
            Yp = partial_labels[:, trainI]
            Ytr = target[:, trainI]

            Xte = data[testI, :]
            Yte = target[:, testI]
            Ypte = partial_labels[:, testI]
            # 将-1变0， 1仍为1
            conf = partial_labels[:, trainI]
            conf[conf == -1] = 0

            # 6个测试集与sample的y测试集不同，需转换标签
            Yp = Yp.astype(np.int8)
            Yp[Yp == 0] = -1
            Ytr = Ytr.astype(np.int8)
            Ytr[Ytr == 0] = -1
            Yte = Yte.astype(np.int8)
            Yte[Yte == 0] = -1
            Ypte = Ypte.astype(np.int8)
            Ypte[Ypte == 0] = -1

            # 原始的mulan数据中，标签是1和0，不是1和-1
            mul_Ytr = target[:, trainI] # todo 测试pml，应该变为partial-target
            mul_Ytr[mul_Ytr == -1] = 0

            mul_Yte = target[:, testI]
            mul_Yte[mul_Yte == -1] = 0

            mul_Ytr_pl = partial_labels[:, trainI]  # todo 测试pml，应该变为partial-target
            mul_Ytr_pl[mul_Ytr_pl == -1] = 0

            mul_Ypte = partial_labels[:, testI]
            mul_Ypte[mul_Ypte == -1] = 0

            lcfs_Ytr, lcfs_Yp, lcfs_Xtr,label_delete,_ = delete_zero(Ytr, Yp, Xtr)
            lcfs_Yte = np.delete(Yte, label_delete,0)
            lcfs_Ypte = np.delete(Ypte, label_delete,0)
            lcfs_conf = np.delete(conf, label_delete, 0)
            eng = matlab.engine.start_matlab()
            #mark = 0 # 标记是否因算法运行时间过长而跳过
            try:
                print("start_alg:")
                # for f in range(1,3,1):
                #"""

                _, new_W = SCMFS(Xtr, mul_Ytr.T, select_nub=-1, alpha=0.1, beta=0.1, gamma=0.3)

                eng1 = matlab.engine.start_matlab()
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro = evaluate(
                    Xte, new_W, mul_Yte.T, eng1)
                SCMFS_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0],
                                     Average_Precision[0][0], F1_micro, F1_macro])


                eng1.quit()
                #"""
                print("###########################################")
                print("对比算法9 ---SCMFS-pl(多标签算法---py版本)", d, "数据集")
            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过SCMFS-pl')

            try:
                print("start_alg:")
                # for f in range(1,3,1):
                #"""
                _, new_W = DRMFS(Xtr, mul_Ytr.T, select_nub=-1, alpha=0.1, beta=0.1, gamma=0.3)
                eng1 = matlab.engine.start_matlab()
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro = evaluate(
                    Xte, new_W, mul_Yte.T, eng1)
                DRMFS_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0],
                                     Average_Precision[0][0], F1_micro, F1_macro])

                eng1.quit()
                #"""
                print("###########################################")
                print("对比算法10 ---DRMFS-pl(多标签算法---py版本)", d, "数据集")
            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过DRMFS-pl')

            try:
                """
                print("start_alg:")
                all_num = Xtr.shape[1]
                _,W1 = MIFS(Xtr, mul_Ytr.T, select_nub=all_num, alpha=0.1, beta=0.1, gamma=0.3)
                eng1 = matlab.engine.start_matlab()
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro = evaluate(Xte, W1, mul_Yte.T,eng1)

                MIFS_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                eng1.quit()
                
                print("###########################################")
                print("对比算法8 ---MIFS-pl(多标签算法---py版本)", d, "数据集")
                """
            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过MIFS-pl')

            try:
                """
                print("start_alg:")
                all_num = Xtr.shape[1]
                _,W1=SSFS(Xtr, mul_Ytr.T, select_nub=all_num, alpha=0.1, beta=0.1, gamma=0.3)

                eng1 = matlab.engine.start_matlab()
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro = evaluate(Xte, W1, mul_Yte.T,eng1)

                SSFS_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                eng1.quit()
                print("###########################################")
                print("对比算法7 ---SSFS-pl(多标签算法---py版本)", d, "数据集")
                """
            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过SSFS-pl')


            # 对比算法1---MLKNN(多标签算法)
            try:  # 设置超时时间为60秒

                #HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro = ML_KNN_process(Xtr, mul_Ytr_pl, Xte, mul_Yte, eng)
                #mlknn_result_pl.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                # 获取W
                #temp_W_name = dir_W + "//mlknn_pl_W.csv"
                #temp_W =get_W_process(Xte,Pre_Labels.T,temp_W_name)
                print("###########################################")
                print("对比算法1 ---MLKNN-pl(多标签算法---matlab版本)",d,"数据集")

            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集',d,'跳过MLKNN-pl')

            try:  # 设置超时时间为60秒

                #HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro  = ML_KNN_process(Xtr, mul_Ytr, Xte, mul_Yte, eng)
                #mlknn_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro ])
                print("###########################################")
                print("对比算法1 ---MLKNN(多标签算法---matlab版本)",d,"数据集")

            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集',d,'跳过MLKNN')

            # 对比算法2---pml_lc && pml_fs(偏多标签算法)
            alg = ['lc', 'fs']
            #eventlet.monkey_patch()  # 必须加这条代码
            try:  # 设置超时时间为60秒（不能为负）

                #HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro = PML_FS_LC_process(lcfs_Xtr,lcfs_Ytr,lcfs_Yp,lcfs_conf,Xte,lcfs_Yte,alg[0],eng)
                #pml_lc_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                print("###########################################")
                print("对比算法2---pml_lc(偏多标签算法)",d,"数据集")

            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集',d,'跳过pml_lc')

            #eventlet.monkey_patch()  # 必须加这条代码
            try:  # 设置超时时间为60秒，不能接受在某个instance的label全为1,测试集在prototype时候也不可有这种情况

                #HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro = PML_FS_LC_process(lcfs_Xtr, lcfs_Ytr, lcfs_Yp, lcfs_conf, Xte, lcfs_Yte, alg[1], eng)
                #pml_fs_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                print("###########################################")
                print("对比算法3---pml_fs(偏多标签算法)", d, "数据集")

            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过pml_fs')
            # 对比算法3---fpml(偏多标签算法)
            #eventlet.monkey_patch()  # 必须加这条代码
            try:  # 设置超时时间为60秒
                # 将python数据转为matlab入参：
                #HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels,F1_micro, F1_macro = fPML_process(Xtr, mul_Ytr, Xte, mul_Yte, mul_Ypte, eng, i, data_count)
                #fpml_result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro, F1_macro])
                print("###########################################")
                print("对比算法4---fpml(偏多标签算法)")

            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过fpml')
            # 对比算法4---PARTICAL(两种便多标签算法)
            #eventlet.monkey_patch()  # 必须加这条代码
            try:  # 设置超时时间为60秒
                par_mark = 0
                # 将python数据转为matlab入参：
                #prelab = PML_Partical_process(Xtr, mul_Ypte, mul_Ytr_pl, Xte, i, prelab, eng)
                print("###########################################")
                print("对比算法5&&6---PARTICAL(两种便多标签算法)")
                par_mark = 1
            except func_timeout.exceptions.FunctionTimedOut:
                print('数据集', d, '跳过PARTICAL(两种便多标签算法)')

            print("Finish the ", i, " time.")
        par_mark = 0
        if par_mark:
            print("###########################################")
            print("对比算法4---PARTICAL(两种便多标签算法)")
            filled_p_data = partial_labels[:,n_test*nfold:m]
            prelab = np.hstack((prelab,filled_p_data))

            mode =[0,1]  # choose par-vls（0） or par-map（1）
            par_vls_result = PML_Partical_alg_result(mode[0], nfold, n_test, m, data, prelab, mul_Y_p, mul_Y)
            par_map_result = PML_Partical_alg_result(mode[1], nfold, n_test, m, data, prelab, mul_Y_p, mul_Y)
        else:
            par_vls_result = []
            par_map_result = []

        #将10次写入csv文件：

        if not os.path.exists('.//none_nega_result//'+dd):
            os.makedirs('.//none_nega_result//'+dd)

        dir = './/none_nega_result//'+dd
        print('dir:',dir)

        write_to_csv_file(dir+'.//par_vls_result.csv', par_vls_result)
        write_to_csv_file(dir+'.//par_map_result.csv', par_map_result)
        write_to_csv_file(dir+'.//fpml_result.csv', fpml_result)
        write_to_csv_file(dir+'.//pml_fs_result.csv',pml_fs_result)
        write_to_csv_file(dir+'.//pml_lc_result.csv',pml_lc_result)
        write_to_csv_file(dir+'.//mlknn_result.csv',mlknn_result)
        write_to_csv_file(dir+'.//mlknn_result_pl.csv',mlknn_result_pl)
        write_to_csv_file(dir + './/MIFS_pl_result.csv', MIFS_result)
        write_to_csv_file(dir + './/SSFS_result_pl.csv', SSFS_result)
        write_to_csv_file(dir + './/SCMFS_result_pl.csv', SCMFS_result)
        write_to_csv_file(dir + './/DRMFS_result_pl.csv', DRMFS_result)
        # 按列求平均：
        mean_vls_map = process_mean(par_vls_result)
        mean_par_map = process_mean(par_map_result)
        mean_fpml = process_mean(fpml_result)
        mean_pml_fs = process_mean(pml_fs_result)
        mean_pml_lc = process_mean(pml_lc_result)
        mean_mlknn = process_mean(mlknn_result)

        #计时：
        e_time = time.time()
        duration = e_time - s_time
        print("总计时：针对"+d+"数据集用时:",duration,"验证完毕！")

        data_count += 1
    print("All Done")