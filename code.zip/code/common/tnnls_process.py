import numpy as np
from skfeature.utility.construct_W import construct_W
from numpy import linalg as LA
from numpy.random import seed

eps = 2.2204e-16


def SSFS(X, Y, select_nub, alpha, beta, gamma):
    num, dim = X.shape
    num, label_num = Y.shape
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}
    Sx = construct_W(X, **options)
    Sx = Sx.A
    Ax = np.diag(np.sum(Sx, 0))
    Lx = Ax - Sx

    k = 10 # 变成全部的分类，dim，可直接返回W

    seed(2)
    V = np.random.rand(num, k)
    B = np.random.rand(dim, k)
    W = np.random.rand(k, label_num)

    iter = 0
    obj = []
    obji = 1

    while 1:
        Btmp = np.sqrt(np.sum(np.multiply(B, B), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)

        V = np.multiply(V, np.true_divide(np.dot(X, B) + alpha * np.dot(Y, W.T) + beta * np.dot(Sx, V),
                                          np.dot(np.dot(V, B.T), B) + alpha * np.dot(np.dot(V, W), W.T) + beta * np.dot(
                                              Ax, V) + eps))

        W = np.multiply(W, np.true_divide(np.dot(V.T, Y), np.dot(np.dot(V.T, V), W) + eps))

        B = np.multiply(B, np.true_divide(np.dot(X.T, V), np.dot(np.dot(B, V.T), V) + gamma * np.dot(D, B) + eps))

        objectives = pow(LA.norm(X - np.dot(V, B.T), 'fro'), 2) + alpha * pow(LA.norm(Y - np.dot(V, W), 'fro'), 2) \
                     + beta * np.trace(np.dot(np.dot(V.T, Lx), V)) + 2 * gamma * np.trace(np.dot(np.dot(B.T, D), B))

        # test:
        #test = np.trace(np.dot(np.dot(V.T, Lx), V))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break


    temp_W = np.dot(B, W)
    score = np.sum(np.multiply(temp_W, temp_W),1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]
    """
    l_new = np.array(l[:select_nub])
    remove_col = np.setdiff1d(np.arange(X.shape[1]), l_new)

    new_W = temp_W.copy()
    new_W[remove_col, :] = np.zeros(label_num)
    """
    return l, temp_W
