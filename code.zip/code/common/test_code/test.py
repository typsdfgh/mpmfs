"""用原始arff文件读入，测试ML-KNN的方法"""


import scipy
import pandas as pd
import numpy as np
from scipy.io import arff
from sklearn.model_selection import train_test_split
from skmultilearn.adapt import MLkNN
from sklearn.metrics import accuracy_score

if __name__ == '__main__':
    print('start')
    # data, meta = scipy.io.arff.loadarff('.\\yeast-train.arff')
    #data, meta = scipy.io.arff.loadarff('.\\emotions.arff')
    data, meta = scipy.io.arff.loadarff('.\\data_arff')
    df = pd.DataFrame(data)
    df.head()

    X = df.iloc[:,0:72].values
    y = df.iloc[:,72:78].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

    y_train = y_train.astype(np.float64)
    y_test = y_test.astype(np.float64)

    classifier = MLkNN()
    # train
    classifier.fit(X_train, y_train)
    # predict
    predictions = classifier.predict(X_test)

    print('Finish')