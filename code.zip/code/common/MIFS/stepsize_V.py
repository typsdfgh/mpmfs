#coding=utf-8
import numpy as np
import math
from numpy import linalg as LA

eps = 2.2204e-16


def stepsize_V(V, grad_V, B, L, Y, alpha, beta):
    c = 0.1
    stepsize = 1
    Vn = V - stepsize * grad_V
    oldobj = alpha * pow(LA.norm(Y - V * B, 'fro'), 2) + beta * np.trace(V.T * L * V)
    newobj = alpha * pow(LA.norm(Y - Vn * B, 'fro'), 2) + beta * np.trace(Vn.T * L * Vn)
    qq = c * np.sum(np.sum(np.multiply(grad_V, Vn - V), 0), 0)
    if (newobj - oldobj) > (c * np.multiply(grad_V, Vn - V).sum()):
        while 1:
            stepsize = stepsize * 0.1  # armijo rule
            Vn = V - stepsize * grad_V
            newobj = alpha * pow(LA.norm(Y - Vn * B, 'fro'), 2) + beta * np.trace(Vn.T * L * Vn)
            if newobj - oldobj <= c * np.multiply(grad_V, Vn - V).sum() + eps:
                break
    else:
        return stepsize

    return stepsize