#coding=utf-8
from numpy import linalg as LA
import math
from numpy import linalg as LA
import numpy as np

eps = 2.2204e-16

def stepsize_W(W, grad_W, X, V, gamma):
    c = 0.1
    stepsize = 1
    Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
    Wn = W - stepsize * grad_W
    Wntmp = np.sqrt(np.sum(np.multiply(Wn, Wn), 1) + eps)
    oldobj = pow(LA.norm(X * W - V, 'fro'), 2) + gamma * np.sum(Wtmp, 0)
    newobj = pow(LA.norm(X * Wn - V, 'fro'), 2) + gamma * np.sum(Wntmp, 0)
    if newobj - oldobj > c * np.multiply(grad_W, Wn - W).sum():
        while 1:
            stepsize = stepsize * 0.1
            Wn = W - stepsize * grad_W
            Wntmp = np.sqrt(np.sum(np.multiply(Wn, Wn), 1) + eps)
            newobj = pow(LA.norm(X * Wn - V, 'fro'), 2) + gamma * np.sum(Wntmp, 0)
            if newobj - oldobj <= c * np.multiply(grad_W, Wn - W).sum() + eps:
                break
    else:
        return stepsize

    return stepsize