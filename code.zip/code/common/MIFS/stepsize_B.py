#coding=utf-8
from numpy import linalg as LA
import math
from numpy import linalg as LA
import numpy as np

eps = 2.2204e-16

def stepsize_B(B, grad_B, V, Y):
    c = 0.1
    stepsize = 1
    Bn = B - stepsize * grad_B
    oldobj = pow(LA.norm(Y - V * B, 'fro'), 2)
    newobj = pow(LA.norm(Y - V * Bn, 'fro'), 2)
    if newobj - oldobj > c * np.multiply(grad_B, Bn - B).sum():
        while 1:
            stepsize = stepsize * 0.1
            Bn = B - stepsize * grad_B
            newobj = pow(LA.norm(Y - V * Bn, 'fro'), 2)
            if newobj - oldobj <= c * np.multiply(grad_B, Bn - B).sum() + eps:
                break
    else:
        return stepsize

    return stepsize
