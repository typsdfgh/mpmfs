import numpy as np
import skfeature.utility.entropy_estimators as ees


def SCLS(data,labels,select_nub):
    """
     new alg
    """

    # max stores max(I(fj;f)-I(fj;f|y)) for each feature f
    # we assign an extreme small value to max[i] ito make it is smaller than possible value of max(I(fj;f)-I(fj;f|y))
    MM = np.zeros(select_nub)
    F=[]
    mm,f_nub=np.shape(data)
    nn,l_nub=np.shape(labels)

    rel=np.zeros((f_nub,1))
    for i in range(f_nub):
        for j in range(l_nub):
            rel[i]=rel[i]+ees.midd(data[:,i],labels[:,j])

    # make sure that j_cmi is positive at the very beginning
    j_cmim = 1

    while True:
        if len(F) == 0:
            # select the feature whose mutual information is the largest
            idx = np.argmax(rel[:,0])
            F.append(idx)
            f_select = data[:, idx]
        if len(F) == select_nub:
                break
        # we assign an extreme small value to j_cmim to ensure it is smaller than all possible values of j_cmim
        j_cmim = -1000000000000
        for i in range(select_nub):
            if i not in F:
                f = data[:, i]
                t2=ees.midd(f,f_select)
                H=ees.entropyd(f)
                if H==0:
                    tmp=0
                else:
                    tmp=t2/H
                tt=tmp*rel[i]
                MM[i]=MM[i]+tt
                if H==0:
                    t=0
                else:
                    t = rel[i]-MM[i]
                # record the largest j_cmim and the corresponding feature index
                if t > j_cmim:
                    j_cmim = t
                    idx = i
        F.append(idx)
        f_select = data[:, idx]
    l = [i for i in F]
    n = 1
    F = [l[i:i + n] for i in range(0, len(l), n)]
    F = np.matrix(F)
    return F[0:select_nub,:]

