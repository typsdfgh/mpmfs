import time
import func_timeout
from func_timeout import func_set_timeout

@func_set_timeout(2)
def e():
    time.sleep(3)

def embed():
    print('embed')
    e()

def task():
    a = 2
    embed()
    return a

if __name__ == '__main__':
    try:
        aa = task()
        print(aa)
    except func_timeout.exceptions.FunctionTimedOut:
        print('task func_timeout')