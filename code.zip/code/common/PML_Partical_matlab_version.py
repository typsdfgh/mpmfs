"""
19年zhang的par-vls && map算法调用matlab common part

due to the process of par, map or vls alg. needs to be dealt after testing

"""

import matlab
import matlab.engine
import time
from process_data import python_to_matlab_matrix, read_general_mat_data, read_compare_exp_result, get_W_process, feature_selection,update_metrics
import scipy.io as io
import numpy as np
from func_timeout import func_set_timeout
from sklearn import metrics
from IDEA1 import evaluate
FR_high_threshold = 50
@func_set_timeout(6000)

def PML_Partical_process(Xtr, Ypte, Yp, Xte, i, prelab, eng):
    k = 10
    alpha = 0.95
    o = 0.9
    k = matlab.double([k])
    alpha = matlab.double([alpha])
    o = matlab.double([o])
    train_data = python_to_matlab_matrix(Xtr, eng)
    train_p_target = python_to_matlab_matrix(Yp, eng)
    test_data = python_to_matlab_matrix(Xte,eng)
    test_p_target = python_to_matlab_matrix(Ypte, eng)
    eng.PAR_train(train_data, train_p_target, k, alpha, nargout=0)

    matr1 = io.loadmat('.\\test_save_partical_train_result.mat')
    d = matr1['model']

    finalConfidence = d[0,0]['finalConfidence']
    disambiguatedLabel = d[0,0]['disambiguatedLabel']
    type = d[0,0]['type']
    fea_num = d[0,0]['fea_num']
    par_k = d[0,0]['k']

    model = {'finalConfidence': finalConfidence, 'disambiguatedLabel': disambiguatedLabel, 'type': type, 'fea_num': fea_num, 'k': par_k}
    io.savemat('.\\saved_struct_partical_train_output.mat', {'model': model})

    eng.PAR_predict(train_data, test_data, test_p_target, o, nargout=0)
    matr2 = io.loadmat('.\\test_save_partical_test_result.mat')
    lab = matr2['lab']
    if i == 0:
        prelab = lab.copy()
    else:
        prelab = np.hstack((prelab, lab))
    eng.quit()

    return prelab

def PML_Partical_alg_result(mode, nfold, n_test, m, data, prelab, partial_labels, target,FR,dir_W,par_d):
    result = []
    for i in range(nfold):
        eng = matlab.engine.start_matlab()
        start_ind = i * n_test
        if (start_ind+n_test) > m:
            testI = np.arange(start_ind, m)
        else:
            testI = np.arange(start_ind,(start_ind+n_test))
        trainI = np.setdiff1d(np.arange(m), testI)

        Xtr = data[trainI, :]
        Np = prelab[:, trainI]
        Yp = partial_labels[:, trainI]
        Xte = data[testI, :]
        Yte = target[:, testI]
        Npte = prelab[:, testI]
        train_data = python_to_matlab_matrix(Xtr, eng)
        train_target = python_to_matlab_matrix(Np, eng)
        pre_target = python_to_matlab_matrix(Yp, eng)
        test_data = python_to_matlab_matrix(Xte, eng)
        test_target = python_to_matlab_matrix(Yte, eng)
        #pre_test_target = python_to_matlab_matrix(Npte, eng)
        if mode == 0:
            start1 = time.time()
            eng.PAR_VLS(train_data,train_target,pre_target,test_data,test_target,nargout=0)
            # 读取数据集
            print("读取数据集---test_save_parvls_final_result.mat")
            matr1 = read_general_mat_data('.\\test_save_parvls_final_result.mat')
            HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels = read_compare_exp_result(
                matr1)
            #F1_micro = metrics.f1_score(Pre_Labels, Yte, labels=[0, 1], average='micro')
            #F1_macro = metrics.f1_score(Pre_Labels, Yte, labels=[0, 1], average='macro')
            F1_micro = metrics.f1_score(Yte, Pre_Labels, labels=[0, 1], average='micro')
            F1_macro = metrics.f1_score(Yte, Pre_Labels, labels=[0, 1], average='macro')
            # 获取W
            temp_W_name = dir_W + "//fpml_W.csv"
            temp_W = get_W_process(Xte, Pre_Labels.T, temp_W_name)
            end1 = time.time()
            d1 = end1 - start1
            for f in range(1, FR, 1):
                start2 = time.time()
                if Xtr.shape[1] > FR_high_threshold:
                    new_f = int(np.ceil(Xtr.shape[1] * f / 100))
                else:
                    new_f = f
                new_W = feature_selection(temp_W, select_nub=new_f, label_num=Yte.shape[0], feature_num=Xtr.shape[1])
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro = evaluate(
                    Xte, new_W, Yte.T, eng)
                end2 = time.time()
                d2 = end2 - start2
                d3 = par_d + d1 + d2
                if i == 0:
                    result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro,F1_macro,d3])
                else:
                    h, r, o, c, a, fi, fa,ddd = update_metrics(result, f, i, HammingLoss, RankingLoss, OneError,
                                                           Coverage, Average_Precision, F1_micro, F1_macro,d3)
                    result[f - 1] = [h, r, o, c, a, fi, fa,ddd]
        elif mode == 1:
            start1 = time.time()
            eng.PAR_MAP(train_data,train_target,pre_target,test_data,test_target,nargout=0)
            # 读取数据集
            print("读取数据集---test_save_parmap_final_result.mat")
            matr2 = read_general_mat_data('.\\test_save_parmap_final_result.mat')
            HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels = read_compare_exp_result(
                matr2)
            F1_micro = metrics.f1_score( Yte, Pre_Labels, labels=[0, 1], average='micro')
            F1_macro = metrics.f1_score( Yte, Pre_Labels, labels=[0, 1], average='macro')

            # 获取W
            temp_W_name = dir_W + "//fpml_W.csv"
            temp_W = get_W_process(Xte, Pre_Labels.T, temp_W_name)
            end1 = time.time()
            d1 = end1 - start1
            for f in range(1, FR, 1):
                start2 = time.time()
                if Xtr.shape[1] > FR_high_threshold:
                    new_f = int(np.ceil(Xtr.shape[1] * f / 100))
                else:
                    new_f = f
                new_W = feature_selection(temp_W, select_nub=new_f, label_num=Yte.shape[0], feature_num=Xtr.shape[1])
                HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro = evaluate(
                    Xte, new_W, Yte.T, eng)
                end2 = time.time()
                d2 = end2 - start2
                d3 = par_d + d1 + d2
                if i == 0:
                    result.append([HammingLoss[0][0], RankingLoss[0][0], OneError[0][0], Coverage[0][0], Average_Precision[0][0],F1_micro,F1_macro,d3])
                else:
                    h, r, o, c, a, fi, fa,ddd = update_metrics(result, f, i, HammingLoss, RankingLoss, OneError,
                                                           Coverage, Average_Precision, F1_micro, F1_macro,d3)
                    result[f - 1] = [h, r, o, c, a, fi, fa,ddd]

        eng.quit()
    return result

