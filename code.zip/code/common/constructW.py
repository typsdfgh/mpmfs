# coding=utf-8
import time
import numpy as np
import math
from scipy.sparse import bsr_matrix
from scipy.sparse import csc_matrix
from MIFS.EuDist2 import EuDist2


# function [W, elapse, M] = constructW(fea,options)
def constructW(fea, options):
    bBinary = 0
    if not 'bSelfConnected' in options:
        options['bSelfConnected'] = 1
        tmp_T = time.clock()
        nSmp, tmp = fea.shape

        maxM = 62500000  # 500M
        BlockSize = int(math.floor(maxM / float(nSmp * 3)))

    if options['NeighborMode'] == 'KNN' and options['k'] > 0:
        if options['Metric'] == 'Euclidean':
            G = np.matrix(np.zeros((nSmp * (options['k'] + 1), 3)))
            for i in range(1, int(math.ceil(nSmp / float(BlockSize))) + 1):
                if i == math.ceil(nSmp / float(BlockSize)):
                    # smpIdx = (i-1)*BlockSize+1:nSmp   #原本的i*BlockSize改为nSmp
                    dist = EuDist2(fea[(i - 1) * BlockSize:nSmp + 1, :], fea, 0)
                    #dist = full(dist);   #????????
                    dump = np.sort(dist, axis=1)
                    idx = np.argsort(dist, axis=1)  # sort each row  升序
                    idx = idx[:, 0:options['k'] + 1]
                    dump = dump[:, 0:options['k'] + 1]
                    if not bBinary:
                        dump = dump.astype(np.float)
                        dump = np.exp(-dump / (2 * options['t'] ** 2)) #####传统除法操作问题
                    G[(i - 1) * BlockSize * (options['k'] + 1):nSmp * (options['k'] + 1) + 1, 0] = np.tile(np.matrix(np.arange((i - 1) * BlockSize, nSmp, 1)).T, ((options['k'] + 1, 1)))
                    aa=np.matrix(idx.T.flatten().T).T
                    G[(i - 1) * BlockSize * (options['k'] + 1):nSmp * (options['k'] + 1) + 1, 1] = aa
                    if not bBinary:
                        ab = np.matrix(dump.T.flatten().T).T
                        G[(i - 1) * BlockSize * (options['k'] + 1):nSmp * (options['k'] + 1) + 1, 2] = ab
                    else:
                        G[(i - 1) * BlockSize * (options['k'] + 1):nSmp * (options['k'] + 1) + 1, 2] = 1.0
                else:
                    # smpIdx = (i-1)*BlockSize+1:i*BlockSize;    %smpIdx向量(a,b)
                    dist = EuDist2(fea[(i - 1) * BlockSize:i * BlockSize, :], fea,
                                   0)  # dist规模： nSample_a(smpIdx)* nSample_b(n)
                    # 取feature矩阵a到b行，包括a,b两行，作为矩阵，计算欧几里得距离并获得距离矩阵并转满矩阵
                    # dist = full(dist);
                    dump = np.sort(dist, axis=1)
                    idx = np.argsort(dist, axis=1)
                    # sort each row sort(A,2)对每行中的元素进行排序，dump已经排序好的矩阵，idx已排序号的矩阵元素序号索引
                    idx = idx[:, 0:options['k'] + 1]  # 取每行值最大的前options.k+1个元素索引，why K+1?
                    dump = dump[:, 0:options['k'] + 1]  # 取每行值最大的前options.k+1个元素，why K+1?
                    if not bBinary:  # 处理
                        dump = np.exp(-dump / (2 * options['t'] ** 2))  # 论文中exp()公式，为什么dump没有平方？
                    # G = zeros(nSmp*(options.k+1),3)
                    # smpIdx = (i-1)*BlockSize+1:i*BlockSize
                    G[(i - 1) * BlockSize * (options['k'] + 1):i * BlockSize * (options['k'] + 1), 0] = np.tile(np.matrix(np.arange((i - 1) * BlockSize, i * BlockSize, 1)).T, ((options['k'] + 1, 1)))
                    # 以smpIdx'为模块，构成（options.k+1）*1的矩阵
                    aa = idx.T.flatten().T
                    bb = G[(i - 1) * BlockSize * (options['k'] + 1):i * BlockSize * (options['k'] + 1), 1]
                    G[(i - 1) * BlockSize * (options['k'] + 1):i * BlockSize * (options['k'] + 1),1] = idx.T.flatten().T
                    # idx的行数(i-1)*BlockSize+1:i*BlockSize，idx的列数options.k+1,A(:)按列由上到下遍历A
                    if not bBinary:
                        G[(i - 1) * BlockSize * (options['k'] + 1):i * BlockSize * (options['k'] + 1),2] = dump.T.flatten().T
                    # else:
                    # G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = 1

            W = csc_matrix((G[:, 2:3].flatten().A[0], (G[:, 0:1].flatten().A[0], G[:, 1:2].flatten().A[0])),shape=(nSmp, nSmp)).toarray()

        W = np.maximum(W, W.T)

        elapse = time.clock() - tmp_T

        return W, elapse

#
# if __name__ == '__main__':
#     fea = np.matrix(
#         [[1, 0, 1, 0], [1, 0, 1, 0], [1, 1, 1, 1], [0, 1, 0, 0], [0, 1, 1, 0], [1, 0, 0, 1], [0, 0, 0, 1], [0, 0, 0, 0],
#          [0, 1, 0, 1], [0, 0, 1, 1]])
#     options = {'Metric': 'Euclidean', 'NeighborMode': 'KNN', 'k': 5, 'WeightMode': 'HeatKernel', 't': 1}
#     W = constructW(fea, options)
#     print W
