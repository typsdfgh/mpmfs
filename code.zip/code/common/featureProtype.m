function Q = featureProtype(train_data,train_target)
%测试方法：
%train_data = train_data';
%train_target = train_target';

[num_class, ~] = size(train_target);
%display(num_class)
[~, dim] = size(train_data);
%display(dim)
Q = zeros(num_class, dim);

for k = 1:num_class
    inds = find(train_target(k,:)==1);
	Q(k,:) = sum(train_data(inds,:))/length(inds);
	%对比matlab结果打桩：
	%if k == 1
	%    display(inds);
	%end

end
%方法二：存储四个输出参数
save('.\\test_save_fslc_featureProtype_result.mat','Q');


end