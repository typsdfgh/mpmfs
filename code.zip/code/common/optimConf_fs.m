function [ optimConf,minObj ] = optimConf_fs(conf,train_data,train_target,Eps,correlation,prototype,par)

[num_class,num_train] = size(train_target);

for i=1:num_train
        Y(i) = sum(train_target(:,i) == 1);
        Ybar(i) = num_class - Y(i);
        gamma(i,1) = 1/(Y(i)*Ybar(i));
        gamma(i,2) = 1/(Y(i)*Y(i));
end

C2 = par.C2;
C3 = par.C3;
max_iter = par.max_iter;
tol = par.tol;


dim = size(train_data,2);

opts = optimset('Algorithm','interior-point','Display','off','MaxIter',400);
temp = 0;
convergence=zeros(1,max_iter);
iteration = 0;
while true
    iteration = iteration+1;
    counter = zeros(1,num_train);
    for k=1:num_class
        f = zeros(num_train,1);
        b = zeros(num_train,1);
        pos_inds = find(train_target(k,:)==1);
        A = sparse(pos_inds,pos_inds,-ones(1,length(pos_inds)),num_train,num_train);
        neg_inds = find(train_target(k,:)==-1);
        Aeq = sparse(neg_inds,neg_inds,ones(1,length(neg_inds)),num_train,num_train);
        beq = zeros(num_train,1);
        flag = 1;
        for i = 1:num_train
            if train_target(k,i)==1
                temp = gamma(i,1)*sum(Eps{k,1}(flag:flag+Ybar(i)-1));
                flag = flag+Ybar(i);
                
                temp = temp+gamma(i,2)*sum(Eps{k,1}(flag:flag+Y(i)-1));
                flag = flag+Y(i);
                

                temp = temp-gamma(i,2)*sum(Eps{k,1}(flag:flag+Y(i)-1));
                flag = flag+Y(i);
                %f(i) = temp - C2*(correlation(k,:)*conf(:,i)) + C3*norm(train_data(i,:)-prototype(k,:))/dim;

                %f(i) = temp - C2*(correlation(k,:)*conf(:,i));

                f(i) = temp + C3*norm(train_data(i,:)-prototype(k,:))/dim;%拆分后表示pml-fs


                b(i) = -1 + sum(conf(train_target(:,i)==1,i)) - conf(k,i);
            else
                
                flag = flag+Y(i);

            end
        end
        ub = ones(num_train,1);
        lb = zeros(num_train,1);
        
        x0 = conf(k,:)';
        % 自测python报错问题：
        %display([num2str(sum(sum(1*(isnan(f)))))]);
        %display([num2str(sum(sum(1*(isnan(A)))))]);
        %display([num2str(sum(sum(1*(isnan(b)))))]);
        %display([num2str(sum(sum(1*(isnan(Aeq)))))]);
        %display([num2str(sum(sum(1*(isnan(beq)))))]);
        %display([num2str(sum(sum(1*(isnan(lb)))))]);
        %display([num2str(sum(sum(1*(isnan(ub)))))]);
        %display([num2str(sum(sum(1*(isnan(x0)))))]);

        [X,fval] = linprog(f,A,b,Aeq,beq,lb,ub,x0,opts);
        conf(k,:) = X';
        temp = temp+fval;
    end
    convergence(iteration) = temp;
%     fprintf('iteration: %d  loss: %.5f\n', iteration, convergence(iteration));
    if iteration ==1
        minObj = convergence(iteration);
        optimConf = conf;
    else
        if convergence(iteration)<=minObj
            minObj = convergence(iteration);
            optimConf=conf;
        end
        if abs(convergence(iteration) - convergence(iteration-1)) <= tol*abs(convergence(iteration))
            fprintf('optimization converge at ratio difference %f\n',tol);
            break;
        end
    end
    if iteration>max_iter
        fprintf('exceed maximum iterations\n');
        break;
    end
end

end
