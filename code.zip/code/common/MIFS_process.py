# coding=utf-8

import time as tm
import numpy as np
from MIFS.stepsize_B import stepsize_B
from MIFS.stepsize_V import stepsize_V
from MIFS.stepsize_W import stepsize_W
# from MIFS.constructW import constructW
from skfeature.utility.construct_W import construct_W
from numpy import linalg as LA
from random import seed

# Input: X instance matrix, row denotes instance
#        Y label matrix
#        alpha,beta,gamma model parameters
#        V_dim dimension of latent space
# Output: idx ranking results of features
#         time running time
#         W coefficient matrix of X
eps = 2.2204e-16


def MIFS(X_train, y_train, select_nub,alpha,beta,gamma):
    V_dim = 10
    eps = 2.2204e-16
    mode = 'amijo'

    n, m = y_train.shape
    temp, d = X_train.shape

    # options = {'Metric': 'Euclidean', 'NeighborMode': 'KNN', 'k': 5, 'WeightMode': 'HeatKernel',
    #            't': 1}  # K - nearest neighbor(字典形式)
    #
    # S, temp = constructW(X_train, options)
    # L = np.diag(np.sum(S, 1)) - S

    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}
    S = construct_W(X_train, **options)
    S = S.A
    A = np.diag(np.sum(S, 0))
    L = A - S

    t0 = tm.time()
    #  initial process
    maxIter = 1000
    stepsize = 0.00001
    k = min(V_dim, m)
    seed(4)
    V = np.mat(np.random.rand(n, k))
    B = np.mat(np.random.rand(k, m))
    W = np.mat(np.random.rand(d, k))
    Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
    d = 0.5 / Wtmp
    D = np.diag(d.flat)
    # iteration start
    iter = 0
    obj = [] #pow(LA.norm(X*W-V,'fro'),2) + alpha*pow(LA.norm(Y-V*B,'fro'),2) + beta*np.trace(V.T*L*V) + gamma*np.sum(Wtmp,0)]
    while iter <= maxIter:
        X_temp = X_train * W
        grad_V = 2 * (V - X_temp + alpha * (V * B - y_train) * B.T + beta * L * V)
        grad_B = 2 * (V.T * (V * B - y_train))
        grad_W = 2 * (X_train.T * (X_temp - V) + gamma * D * W)
        if mode == 'amijo':  # employ amijo rule to set the stepsize in each iteration
            V = V - stepsize_V(V, grad_V, B, L, y_train, alpha, beta) * grad_V
            B = B - stepsize_B(B, grad_B, V, y_train) * grad_B
            W = W - stepsize_W(W, grad_W, X_train, V, gamma) * grad_W
        elif mode == 'fix':  # fix the stepsize
            V = V - stepsize * grad_V
            B = B - stepsize * grad_B
            W = W - stepsize * grad_W

        obj.append(
            pow(LA.norm(X_train * W - V, 'fro'), 2) + alpha * pow(LA.norm(y_train - V * B, 'fro'), 2) + beta * np.trace(
                V.T * L * V) + gamma * np.sum(Wtmp, 0))
        # print('the object value in iter %d is %f' % (iter, obj[iter]))

        if (iter > 1 and (iter == 300 or abs(obj[iter] - obj[iter - 1]) < 1e-5 or abs(obj[iter] - obj[iter - 1]) / float(abs(
                iter)) < 1e-5)):  # abs(obj(iter)-obj(iter-1))/abs(iter)   why?
            break

        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        d = 0.5 / (Wtmp)
        D = np.diag(d.flat)
        iter = iter + 1

    temp_W = np.dot(W, B)

    score = np.sum(np.multiply(W, W), 1)
    # 验证后，同score1
    #score1 = np.sum(np.multiply(temp_W, temp_W),1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()[0]
    #idx1 = np.argsort(-score, axis=0)
    #idx1 = idx1.T.tolist()[0]
    #time = tm.time() - t0
    l = [i for i in idx]
    """
    l_new = np.array(l[:select_nub])
    remove_col = np.setdiff1d(np.arange(X_train.shape[1]), l_new)

    new_W = temp_W.copy()
    new_W[remove_col,:] = np.zeros(m)
    new_W = new_W.A
    """
    return l, temp_W