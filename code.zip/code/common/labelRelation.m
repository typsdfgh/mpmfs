function S = labelRelation(label)

[num_class, ~] = size(label);

S = zeros(num_class);
for i = 1:num_class
	for j = 1:num_class
		if i~=j
			A = sum((label(i,:)==1)&(label(j,:)==1));
			B = sum((label(i,:)==1)&(label(j,:)==-1));
			C = sum((label(i,:)==-1)&(label(j,:)==1));
			D = sum((label(i,:)==-1)&(label(j,:)==-1));
           
			S(i,j) = (A*D - B*C) / sqrt((A+B)*(C+D)*(A+C)*(B+D));
            
		end
	end
end

S_max = max(max(S));
S_min = min(min(S));
S = (S - S_min)/(S_max - S_min);


for i = 1:num_class
    S(i,i) = 0;
end
%方法二：存储四个输出参数
save('.\\test_save_fslc_corr_result.mat','S');

end