import os
import pandas as pd
import csv


def write_integrate_feature(dir, index_name, avg_lst):
    # filename = dir + '\\integrate_result-test.csv'
    filename = dir + index_name
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['dataset', 'alg', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16',
             '17', '18', '19'])
        for i in avg_lst:

            writer.writerow(i)


def integrate_feature(dir):
#if __name__ == '__main__':
    #dir = './/none_nega_feature_result//'
    #dir = '.\\none_nega_feature_result'
    alg_lst = ['mlknn_result.csv','mlknn_result_pl.csv','MIFS_pl_result.csv',
               'SSFS_result_pl.csv','fpml_result.csv','pml_lc_result.csv',
               'pml_fs_result.csv','par_vls_result.csv','par_map_result.csv',
               'DRMFS_result_pl.csv', 'SCMFS_result_pl.csv']
    dataset = ['3source','Bibtex','Birds','CAL','Chess','Corel5k','Delicious',
               'Enron','Flags','LLOG_F','Mediamill','test','Water','Yeast',
               'CHD_49','foodtruck','HumanPseAAC','PlantPseAAC','Reuters-K500','Slashdot','Scene']
    #dataset = ['test','test2']

    hl = []
    rl = []
    oe = []
    co = []
    ap = []
    fmi = []
    fma = []
    dr = []

    # 读取目录下数据并处理：
    r_dataset =os.listdir(dir)

    for d in dataset:
        if d in r_dataset:
            file_dir = os.path.join(dir, d)
            file_lst = os.listdir(file_dir)

            count = 0
            for f in alg_lst:

                if f in file_lst and count == 0:
                    f_addr = os.path.join(file_dir,f)
                    df = pd.read_csv(f_addr)
                    #col_mean = df.mean(axis=0)

                    temp = df['HammingLoss'].tolist()
                    temp = [d, f] + temp
                    hl.append(temp)
                    temp = df['RankingLoss'].tolist()
                    temp = [d, f] + temp
                    rl.append(temp)
                    temp = df['OneError'].tolist()
                    temp = [d,f]+temp
                    oe.append(temp)
                    temp = df['Coverage'].tolist()
                    temp = [d,f]+temp
                    co.append(temp)
                    temp = df['Average_Precision'].tolist()
                    temp = [d,f] + temp
                    ap.append(temp)
                    temp = df['F1-micro'].tolist()
                    temp = [d,f] + temp
                    fmi.append(temp)
                    temp = df['F1-macro'].tolist()
                    temp = [d,f] + temp
                    fma.append(temp)

                    temp = df['duration'].tolist()
                    temp = [d,f] + temp
                    dr.append(temp)

                elif f in file_lst and count > 0:
                    f_addr = os.path.join(file_dir, f)
                    df = pd.read_csv(f_addr)
                    temp = df['HammingLoss'].tolist()
                    temp = ['', f] + temp
                    hl.append(temp)
                    temp = df['RankingLoss'].tolist()
                    temp = ['', f] + temp
                    rl.append(temp)
                    temp = df['OneError'].tolist()
                    temp = ['', f] + temp
                    oe.append(temp)
                    temp = df['Coverage'].tolist()
                    temp = ['', f] + temp
                    co.append(temp)
                    temp = df['Average_Precision'].tolist()
                    temp = ['', f] + temp
                    ap.append(temp)
                    temp = df['F1-micro'].tolist()
                    temp = ['', f] + temp
                    fmi.append(temp)
                    temp = df['F1-macro'].tolist()
                    temp = ['', f] + temp
                    fma.append(temp)

                    temp = df['duration'].tolist()
                    temp = ['', f] + temp
                    dr.append(temp)

                elif f not in file_lst and count == 0:
                    temp = [d, f, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
                    hl.append(temp)
                    rl.append(temp)
                    oe.append(temp)
                    co.append(temp)
                    ap.append(temp)
                    fmi.append(temp)
                    fma.append(temp)
                    dr.append(temp)
                else:
                    temp = ['', f, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
                    hl.append(temp)
                    rl.append(temp)
                    oe.append(temp)
                    co.append(temp)
                    ap.append(temp)
                    fmi.append(temp)
                    fma.append(temp)
                    dr.append(temp)
                count += 1



        else:
            temp = [d, '#','#']
            hl.append(temp)
            rl.append(temp)
            oe.append(temp)
            co.append(temp)
            ap.append(temp)
            fmi.append(temp)
            fma.append(temp)
            dr.append(temp)
    # 写入目录下数据并处理：
    write_integrate_feature(dir, '\\HammingLoss.csv', hl)
    write_integrate_feature(dir, '\\RankingLoss.csv', rl)
    write_integrate_feature(dir, '\\Oneerror.csv', oe)
    write_integrate_feature(dir, '\\Coverage.csv', co)

    write_integrate_feature(dir, '\\Average_Precision.csv', ap)
    write_integrate_feature(dir, '\\F1_micro.csv', fmi)
    write_integrate_feature(dir, '\\F1_macro.csv', fma)
    write_integrate_feature(dir, '\\Duration.csv', dr)



    print('FINISH')


