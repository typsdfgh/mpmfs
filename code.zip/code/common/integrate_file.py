import os
import pandas as pd
import csv

if __name__ == '__main__':
    dir = '.\\none_nega_result'
    alg_lst = ['mlknn_result.csv','mlknn_result_pl.csv','MIFS_pl_result.csv',
               'SSFS_result_pl.csv','fpml_result.csv','pml_lc_result.csv',
               'pml_fs_result.csv','par_vls_result.csv','par_map_result.csv']
    dataset = ['3source','Bibtex','Birds','CAL','Chess','Corel5k','Delicious',
               'Enron','Flags','LLOG_F','Mediamill','test','Water','Yeast']
    # 读取目录下数据并处理：
    r_dataset =os.listdir(dir)
    avg_lst = []
    for d in dataset:
        if d in r_dataset:
            file_dir = os.path.join(dir, d)
            file_lst = os.listdir(file_dir)
            temp_lst = []
            count = 0
            for f in alg_lst:

                if f in file_lst and count == 0:
                    f_addr = os.path.join(file_dir,f)
                    df = pd.read_csv(f_addr)
                    col_mean = df.mean(axis=0)
                    if len(col_mean) == 7:
                        temp = [d,f,col_mean['HammingLoss'],col_mean['RankingLoss'],col_mean['OneError'],col_mean['Coverage'],col_mean['Average_Precision'],
                            col_mean['F1-micro'],col_mean['F1-macro']
                            ]
                    else:
                        temp = ['', f, col_mean['HammingLoss'], col_mean['RankingLoss'], col_mean['OneError'],
                                col_mean['Coverage'], col_mean['Average_Precision'],
                                # col_mean['F1-micro'], col_mean['F1-macro']
                                ]
                    temp_lst.append(temp)
                elif f in file_lst and count > 0:
                    f_addr = os.path.join(file_dir, f)
                    df = pd.read_csv(f_addr)
                    col_mean = df.mean(axis=0)
                    if len(col_mean) == 7:
                        temp = ['',f, col_mean['HammingLoss'], col_mean['RankingLoss'], col_mean['OneError'],
                            col_mean['Coverage'], col_mean['Average_Precision'],
                            col_mean['F1-micro'],col_mean['F1-macro']
                            ]
                    else:
                        temp = ['', f, col_mean['HammingLoss'], col_mean['RankingLoss'], col_mean['OneError'],
                                col_mean['Coverage'], col_mean['Average_Precision'],
                                #col_mean['F1-micro'], col_mean['F1-macro']
                                ]
                    temp_lst.append(temp)
                elif f not in file_lst and count == 0:
                    temp_lst.append([d,f,-1,-1,-1,-1,-1,-1,-1])
                else:
                    temp_lst.append(['',f, -1, -1, -1, -1, -1, -1, -1])
                count += 1


            avg_lst.append(temp_lst)
        else:
            avg_lst.append([d,'#','#','#'])
    # 写入目录下数据并处理：
    filename = dir + '\\integrate_result-test.csv'
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(
            ['dataset','alg','HammingLoss', 'RankingLoss', 'OneError', 'Coverage', 'Average_Precision', 'F1-micro', 'F1-macro'])
        for i in avg_lst:
            if len(i[0]) == 1: # 从i【1】改为i【0】
                writer.writerow(i)
            else:
                for j in i:
                    writer.writerow(j)
    print('FINISH')


