function [RankingLosses,OneErrors,AveragePrecisions,Hamminglosses,coverages,p, Pre_Labels]=evaluate2(predict_values, GroundTruth)

GroundTruth1=GroundTruth;
GroundTruth1(GroundTruth1==-1)=0;
% ======================Evaluation metrics=================================
RankingLosses= Ranking_loss(predict_values',GroundTruth1'); % 统一不再1-xxx
OneErrors= One_error(predict_values',GroundTruth1');% 统一不再1-xxx
AveragePrecisions= Average_precision(predict_values',GroundTruth1');

%补充两个：
%Evaluation% 每种方式的prelabel置1的算法设计不同，此种方式同mlknn，但0.5阈值不同
[num_class,num_testing]=size(predict_values');
p=predict_values';
Pre_Labels=zeros(num_class,num_testing);
for i=1:num_testing
    for j=1:num_class
        if(p(j,i)>=0.5)
            Pre_Labels(j,i)=1;
        else
            Pre_Labels(j,i)=0;
        end
    end
end
Hamminglosses= Hamming_loss(Pre_Labels, GroundTruth1');% 统一不再1-xxx
coverages = coverage(predict_values', GroundTruth1');% 统一不再1-xxx