import matlab
from process_data import python_to_matlab_matrix, read_general_mat_data
from func_timeout import func_set_timeout
from sklearn import metrics
@func_set_timeout(6000)

def ML_KNN_process(Xtr, Ytr, Xte, Yte, eng):
    Num = 10
    Num = matlab.double([Num])
    Smooth = 1.0
    Smooth = matlab.double([Smooth])

    # 将python数据转为matlab入参：
    train_data = python_to_matlab_matrix(Xtr, eng)
    train_target = python_to_matlab_matrix(Ytr, eng)

    eng.MLKNN_train(train_data, train_target, Num, Smooth, nargout=0)
    # 读取数据集
    print("读取数据集---test_save_train_result.mat")
    # Prior, PriorN, Cond, CondN = read_interval_data('.\\test_save_train_result.mat')
    matrix_dict = read_general_mat_data('.\\test_save_train_result.mat')
    Prior = matrix_dict['Prior']
    PriorN = matrix_dict['PriorN']
    Cond = matrix_dict['Cond']
    CondN = matrix_dict['CondN']

    test_data = python_to_matlab_matrix(Xte, eng)
    test_target = python_to_matlab_matrix(Yte, eng)

    Prior = python_to_matlab_matrix(Prior, eng)
    PriorN = python_to_matlab_matrix(PriorN, eng)
    Cond = python_to_matlab_matrix(Cond, eng)
    CondN = python_to_matlab_matrix(CondN, eng)

    eng.MLKNN_test(train_data, train_target, test_data, test_target, Num, Prior, PriorN, Cond, CondN, nargout=0)
    # 读取数据集
    print("读取数据集---test_save_test_result.mat")
    matrix_dict_2 = read_general_mat_data('.\\test_save_test_result.mat')
    HammingLoss = matrix_dict_2['HammingLoss']
    RankingLoss = matrix_dict_2['RankingLoss']
    OneError = matrix_dict_2['OneError']
    Coverage = matrix_dict_2['Coverage']
    Average_Precision = matrix_dict_2['Average_Precision']
    Outputs = matrix_dict_2['Outputs']
    Pre_Labels = matrix_dict_2['Pre_Labels']

    F1_micro = metrics.f1_score(Pre_Labels, Yte, labels=[0, 1], average='micro')
    F1_macro = metrics.f1_score(Pre_Labels, Yte, labels=[0, 1], average='macro')

    return HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro