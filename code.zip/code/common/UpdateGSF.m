function [S, F, G, iterValue] = UpdateGSF(X,Y, F1, options)

maxIter=options.maxIter;
lamda1=options.lamda1;
lamda2=options.lamda2;
% lamda3 = options.lamda3;
K=options.K;

iterValue=zeros(1,maxIter);

[mLabel,~]=size(Y);
[mFeature,nSmp]=size(X);

S= abs(rand(mLabel,K));
F= abs(rand(mFeature,K));
G = abs(rand(nSmp,K));
% W = abs(rand(mFeature,mLabel));

nIter = 1;
while nIter <= maxIter
    % ===================== update G ========================
    YS=Y'*S;
    XF=X'*F;
%     XWS=X'*W*S;
    XWS=F1'*S;
    GSS=G*(S'*S);
    GFF=G*(F'*F);
    
    YS_plus=(abs(YS)+YS)/2;
    YS_minus=(abs(YS)-YS)/2;
    XF_plus=(abs(XF)+XF)/2;
    XF_minus=(abs(XF)-XF)/2;
    XWS_plus=(abs(XWS)+XWS)/2;
    XWS_minus=(abs(XWS)-XWS)/2;
    GSS_plus=(abs(GSS)+GSS)/2;
    GSS_minus=(abs(GSS)-GSS)/2;
    GFF_plus=(abs(GFF)+GFF)/2;
    GFF_minus=(abs(GFF)-GFF)/2;
    
    numerator=YS_plus+(lamda2+1)*GSS_minus+lamda1*XF_plus+lamda1*GFF_minus+lamda2*XWS_plus;
    denominator=YS_minus+(lamda2+1)*GSS_plus+lamda1*XF_minus+lamda1*GFF_plus+lamda2*XWS_minus;
%     G = G.*sqrt(numerator./max(denominator,1e-10));
    G = G.*(numerator./max(denominator,1e-10));
    % ===================== update S ========================
    YG=Y*G;
%     WXG=W'*X*G;
    WXG=F1*G;
    SGG=S*(G'*G);
    
    YG_plus=(abs(YG)+YG)/2;
    YG_minus=(abs(YG)-YG)/2;
    WXG_plus=(abs(WXG)+WXG)/2;
    WXG_minus=(abs(WXG)-WXG)/2;
    SGG_plus=(abs(SGG)+SGG)/2;
    SGG_minus=(abs(SGG)-SGG)/2;
    
    numerator=YG_plus+(lamda2+1)*SGG_minus+lamda2*WXG_plus;
    denominator=YG_minus+(lamda2+1)*SGG_plus+lamda2*WXG_minus;
%     S = S.*sqrt(numerator./max(denominator,1e-10));
    S = S.*(numerator./max(denominator,1e-10));
    % ===================== update F ========================
    if lamda1>0
        F=(X*G)/(G'*G);
    end
    %========================================================
    obj = CalculateObj(X, Y, S, F, G, F1, lamda1, lamda2);
    iterValue(nIter)=obj;
    nIter = nIter + 1;
end

function [obj] = CalculateObj(X, Y, S, F, G, F1, lamda1, lamda2)

dY = S*G'-Y;
obj_NMF= sum(sum(dY.^2));
if lamda1>0
    dX = F*G'-X;
    obj_NMF1= sum(sum(dX.^2));
else
    obj_NMF1=0;
end

if lamda2>0
    dWX = F1-S*G';
    obj_NMF2= sum(sum(dWX.^2));
else
    obj_NMF2=0;
end
obj =obj_NMF+ lamda1*obj_NMF1+ lamda2*obj_NMF2;

