function AA1=mat2py_list(AA0)
%输入：matlab矩阵
%输出：python list类型矩阵
    len1=size(AA0,1);
    len2=size(AA0,2);
    AA=reshape(AA0,1,len1*len2);

    AA1=py.list(AA);
    %AA2=py.numpy.reshape(AA1,[int8(len1),int8(len2)]);
    %AA3=py.list(AA2);
end

