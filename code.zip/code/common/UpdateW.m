function [W, funcVal] = UpdateW(X, Y, S, G, options)

lamda2=options.lamda2;
lamda3 = options.lamda3;

[~,mLabel]=size(Y);
X1=cell(1,mLabel);
Y1=cell(1,mLabel);
for i=1:mLabel
%     X1{i}=X';
    X1{i} = [X ones(size(X, 1), 1)]; % add bias. 
end
SG=S*G';
for i=1:mLabel
    Y1{i}=SG(i,:)';
end
[W, funcVal] = Least_Lasso(X1, Y1, lamda3/(2*lamda2));  % refer to the  Reference [1] and [2].
%  Reference:
% [1] Tibshirani, J. Regression shrinkage and selection via  the Lasso, Journal of the Royal Statistical Society. Series B 1996
% [2] Jiayu Zhou, Jianhui Chen, Jieping Ye, MALSAR: Multi-tAsk Learning via  StructurAl Regularization, 2012. 
         %  code can be found in   https://github.com/jiayuzhou/MALSAR
