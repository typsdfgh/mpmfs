# coding=UTF-8
import numpy as np
from numpy import linalg as LA

def SCMFS(X_train,y_train, select_nub,alpha,beta,gamma):
    X_train = np.matrix(X_train)
    y_train = np.matrix(y_train)
    maxIter = 1000
    V_dim = 10
    eps = 2.2204e-16
    n, d = X_train.shape
    n, c = y_train.shape
    k = min(V_dim, c)
    
    W = abs(np.mat(np.random.rand(d, k)))
    V = abs(np.mat(np.random.rand(n, k)))
    Q = abs(np.mat(np.random.rand(k, d)))
    B = abs(np.mat(np.random.rand(k, c)))

    Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
    d1 = 0.5 / Wtmp
    D = np.diag(d1.flat)

    iter = 0
    obj = []
    while iter < maxIter:
        W = np.multiply(W,np.true_divide(X_train.T*V,X_train.T*X_train*W + gamma*(D*W)+eps))
        V = np.multiply(V,np.true_divide(X_train*W+alpha*X_train*Q.T+beta*y_train*B.T,V+alpha*V*Q*Q.T+beta*V*B*B.T+eps))
        Q = np.multiply(Q,np.true_divide(V.T*X_train,V.T*V*Q+eps))
        B = np.multiply(B,np.true_divide(V.T*y_train,V.T*V*B+eps))
        
        obj.append(pow(LA.norm(X_train*W - V, 'fro'), 2) + alpha*pow(LA.norm(X_train - V*Q, 'fro'),
                      2) + beta*pow(LA.norm(V*B - y_train, 'fro'), 2) + gamma * np.sum(Wtmp, 0))

        if (iter > 1 and (iter == 300 or abs(obj[iter] - obj[iter - 1]) < 1e-3 or abs(obj[iter] - obj[iter - 1]) / float(
                abs(obj[iter-1])) < 1e-3)):
            break

        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        d1 = 0.5 / Wtmp
        D = np.diag(d1.flat)
        iter = iter + 1

    temp_W = np.dot(W,B)
    score = np.sum(np.multiply(temp_W, temp_W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]

    return l, temp_W

