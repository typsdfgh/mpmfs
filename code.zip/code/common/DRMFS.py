# coding=utf-8
import numpy as np
from numpy import linalg as LA
import scipy
from skfeature.utility.construct_W import construct_W
eps = 2.2204e-16

# Dual graph regularized multi-label feature selection based on the robust loss function


def DRMFS(X, Y, select_nub, alpha, beta, gamma):
    X = X.T
    dim, n = np.shape(X)
    n, label = np.shape(Y)

    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}

    Sx = construct_W(X, **options)
    Sx = Sx.A
    Ax = np.diag(np.sum(Sx, 0))
    Lx = Ax - Sx

    Y0 = Y.T
    Sy = construct_W(Y0, **options)
    Sy = Sy.A
    Ay = np.diag(np.sum(Sy, 0))
    Ly = Ay - Sy

    W = abs(np.random.rand(dim, label))
    iter = 0
    obj = []
    obji = 1

    XWTY = np.dot(X.T, W) - Y
    while 1:
        # update D
        WWtmp = np.sqrt(np.sum(np.multiply(XWTY, XWTY), 1) + eps)
        d1 = 0.5 / WWtmp
        D = np.diag(d1.flat)

        # update U
        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        u1 = 0.5 / Wtmp
        U = np.diag(u1.flat)

        # update W
        W = np.multiply(W, np.true_divide(np.dot(np.dot(X, D), Y) + alpha * np.dot(Sx, W) + beta * np.dot(W, Sy),
                                          np.dot(np.dot(np.dot(X, D), X.T), W) + alpha * np.dot(Ax, W) + beta * np.dot(
                                              W, Ay) + gamma * np.dot(U, W) + eps))

        XWTY = np.dot(X.T, W) - Y

        objectives = np.sum(np.sqrt(np.sum(np.multiply(XWTY, XWTY), 1) + eps), 0) + alpha * np.trace(
            np.dot(np.dot(W.T, Lx), W)) + beta * np.trace(np.dot(np.dot(W, Ly), W.T)) + gamma * np.sum(
            np.sqrt(np.sum(np.multiply(W, W), 1) + eps), 0)

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-3 or iter == 300)):
            break

    temp_W = W
    score = np.sum(np.multiply(temp_W, temp_W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.tolist()
    l = [i for i in idx]
    """
    l_new = np.array(l[:select_nub])
    remove_col = np.setdiff1d(np.arange(X.T.shape[1]), l_new)

    new_W = temp_W.copy()
    new_W[remove_col, :] = np.zeros(label)
    """
    return l, temp_W