
"""
fPML算法调用matlab
"""
from process_data import python_to_matlab_matrix, read_general_mat_data
from func_timeout import func_set_timeout
from sklearn import metrics
@func_set_timeout(6000)





def fPML_process(o_Xtr, o_Ytr, o_Xte, o_Yte, o_Ypte, eng, i, file_count,lambda_1,lambda_2,lambda_3):
    Xtr = python_to_matlab_matrix(o_Xtr, eng)
    Ytr = python_to_matlab_matrix(o_Ytr, eng)
    Xte = python_to_matlab_matrix(o_Xte, eng)
    Yte = python_to_matlab_matrix(o_Yte, eng)
    Ypte = python_to_matlab_matrix(o_Ypte, eng)
    
    eng.fPML_RN(Xtr, Ytr, Xte, Yte, Ypte, i, file_count,lambda_1,lambda_2,lambda_3, nargout=0)
    # 读取数据集
    print("读取数据集---test_save_fpml_test_result.mat")
    matrix_dict_2 = read_general_mat_data('.\\test_save_fpml_test_result.mat')
    HammingLoss = matrix_dict_2['HammingLoss']
    RankingLoss = matrix_dict_2['RankingLoss']
    OneError = matrix_dict_2['OneError']
    Coverage = matrix_dict_2['Coverage']
    Average_Precision = matrix_dict_2['Average_Precision']
    Outputs = matrix_dict_2['Outputs']
    Pre_Labels = matrix_dict_2['Pre_Labels']

    F1_micro = metrics.f1_score(Pre_Labels, o_Yte, labels=[0, 1], average='micro')
    F1_macro = metrics.f1_score(Pre_Labels, o_Yte, labels=[0, 1], average='macro')
    return HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro

def Fpml_get_hyper(o_Xtr, o_Ytr, o_Xte, o_Yte, o_Ypte, eng, i, file_count):
    lambda_2=1
    lambda_1=0.1
    lambda_3=10
    grid=[0.001,0.01,1,10,100]
    AP=0
    for para1 in grid:
        HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro=fPML_process(o_Xtr, o_Ytr, o_Xte, o_Yte, o_Ypte, eng, i, file_count,para1,lambda_2,lambda_3)
        if Average_Precision>=AP:
            lambda_1=para1
    AP=0
    for para3 in grid:
        HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Outputs, Pre_Labels, F1_micro, F1_macro=fPML_process(o_Xtr, o_Ytr, o_Xte, o_Yte, o_Ypte, eng, i, file_count,lambda_1,lambda_2,para3)
        if Average_Precision>=AP:
            lambda_3=para3
    return lambda_1,lambda_2,lambda_3

