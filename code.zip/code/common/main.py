"""
pml-fs and pml-lc PYTHON VERSION
"""
import math
import numpy as np
from process_data import read_mat_data
from compare_algs import ML_KNN_ALG
from pml_fs_featureProtype import featureProtype
from pml_fs_labelRelation import labelRelation
from pml_fs_train import fs_lc_train

def split_mat_data():
    return
if __name__ == '__main__':
    print("START")
    # 读取数据集
    print("读取数据集---emotions_partial_4.mat(593,72)")
    data, target, partial_labels = read_mat_data('.\\emotions_partial_4.mat')

    # 切分数据集
    print("###########################################")
    print("切分数据集---emotions_partial_4.mat(474,193)")
    m = target.shape[1]
    num_eps = 20

    np.random.seed(0)
    trainI = np.random.choice(m-1, math.floor(m * 0.8), replace=False)
    testI = np.setdiff1d(np.arange(m), trainI)

    # 测试对比matlab版：
    trainI = np.arange(0, math.floor(m*0.8))
    testI = np.arange(math.floor(m*0.8), m)


    Xtr = data[trainI,:]
    Yp = partial_labels[:,trainI]
    Ytr = target[:,trainI]

    Xte = data[testI,:]
    Yte = target[:,testI]

    #将-1变0， 1仍为1
    conf = partial_labels[:,trainI]
    conf[conf == -1] = 0

    #原始的mulan数据中，标签是1和0，不是1和-1
    mul_Ytr = target[:,trainI]
    mul_Ytr[mul_Ytr == -1] = 0

    mul_Yte = target[:,testI]
    mul_Yte[mul_Yte == -1] = 0

    #对比算法1---MLKNN(多标签算法)
    print("###########################################")
    print("对比算法1 - --MLKNN(多标签算法)")
    predictions, pre_proba = ML_KNN_ALG(mul_Ytr, Xtr, Xte)


    # 对比算法2---pml_lc && pml_fs(偏多标签算法)
    print("###########################################")
    print("对比算法2---pml_lc && pml_fs(偏多标签算法)")
    prototype = featureProtype(Xtr, Ytr)
    correlation = labelRelation(Ytr)
    [num_class, num_train] = Ytr.shape

    par = {'C2':0, 'C3':0.1, 'tol' :1e-4, 'max_iter':10}

    fs_lc_train(Xtr,Yp,conf,correlation,prototype,par)

    print('Finish')
