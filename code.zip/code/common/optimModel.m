function [ trained_w,trained_b,Eps,minObj] = optimModel( train_data,train_target,conf,par)

[num_train, dim] = size(train_data);
num_class = size(train_target,1);

for i=1:num_train
        Y(i) = sum(train_target(:,i) == 1);
        Ybar(i) = num_class - Y(i);
        gamma(i,1) = 1/(Y(i)*Ybar(i));
        gamma(i,2) = 1/(Y(i)*Y(i));
end

tol = par.tol;
max_iter = par.max_iter;

w = zeros(dim,num_class);
b = zeros(1,num_class);

Eps = cell(num_class,1);
xwb = train_data * w;
num_list = zeros(2,num_class);
for j = 1:num_class
    xwb(:,j) = xwb(:,j) + b(1,j);
    num_list(1,j) = sum(Ybar(train_target(j,:) == 1)) + sum(Y(train_target(j,:) == -1))+2*sum(Y(train_target(j,:) == 1));
    Eps{j,1} = zeros(num_list(1,j),1);
end
opts = optimset('Algorithm','interior-point-convex','Display','off','MaxIter',400);
iteration = 0;
convergence = zeros(1,max_iter);


while true
    iteration = iteration+1;
    temp = 0;
    for k=1:num_class
        num_eps = num_list(1,k);
        H = sparse(1:dim,1:dim,ones(1,dim),dim+1+num_eps,dim+1+num_eps);
        
        columnFlag = dim+1+1;
        A_C1 = zeros(num_eps, dim+1);
        A_C2 = sparse(1:num_eps,columnFlag:columnFlag+num_eps-1,-ones(num_eps,1),...
            num_eps,dim+1+num_eps);
        
        A_C1_C2 = sparse(1:num_eps,1:num_eps,-ones(num_eps,1),num_eps,num_eps);
        A_C1(:,dim+1) = 1;
        
        B_C1 = zeros(num_eps, 1);
        F_eps_Xi = zeros(num_eps,1);
        
        rowFlag = 1;
        for i = 1:num_train
             if train_target(k,i) == 1
                 A_C1(rowFlag:rowFlag+Ybar(i)-1,1:dim+1) = -repmat([train_data(i,:),1],Ybar(i),1);
                 B_C1(rowFlag:rowFlag+Ybar(i)-1,1) = (-1)*(1+xwb(i,train_target(:,i) == -1)');
                 F_eps_Xi(rowFlag:rowFlag+Ybar(i)-1,1) = conf(k,i)*gamma(i,1);
                 rowFlag = rowFlag + Ybar(i);
                 
                 A_C1(rowFlag:rowFlag+Y(i)-1,1:dim+1) = -repmat([train_data(i,:),1],Y(i),1);
                 B_C1(rowFlag:rowFlag+Y(i)-1,1) = (-1)*(1+xwb(i,train_target(:,i) == 1)');
                 F_eps_Xi(rowFlag:rowFlag+Y(i)-1,1) = max(0,conf(k,i)-conf(train_target(:,i)==1,i))*gamma(i,2);
                 rowFlag = rowFlag + Y(i);
                 
                 A_C1(rowFlag:rowFlag+Y(i)-1,1:dim) = repmat(train_data(i,:),Y(i),1);
                 B_C1(rowFlag:rowFlag+Y(i)-1,1) = xwb(i,train_target(:,i) == 1)' - 1;
                 F_eps_Xi(rowFlag:rowFlag+Y(i)-1,1) = max(0, conf(train_target(:,i)==1,i)-conf(k,i))*gamma(i,2);
                 rowFlag = rowFlag + Y(i);
             else
                 A_C1(rowFlag:rowFlag+Y(i)-1,1:dim) = repmat(train_data(i,:),Y(i),1);
                 B_C1(rowFlag:rowFlag+Y(i)-1,1) = xwb(i,train_target(:,i) == 1)' - 1;
                 F_eps_Xi(rowFlag:rowFlag+Y(i)-1,1) = conf(train_target(:,i)==1,i)*gamma(i,1);
                 rowFlag = rowFlag + Y(i);
             end
        end
        B_C2 = zeros(num_eps,1);
        B = [B_C1;B_C2];
        
        F_wb = zeros(dim+1,1);
        F = [F_wb;F_eps_Xi];

        x0 = [w(:,k);b(1,k);Eps{k,1}];
        [X,fval] = quadprog(H,F,[sparse(A_C1),A_C1_C2;A_C2],B,[],[],[],[],x0,opts);
        
        w(:,k) = X(1:dim);
        b(1,k) = X(dim+1);
        
        Eps{k,1} = X(dim+2:dim+1+num_eps);
        xwb(:,k) = train_data * w(:,k) + b(1,k);
        temp = temp+fval;
    end

    convergence(iteration) = temp;

    if iteration ==1
        minObj = convergence(iteration);
        trained_w = w;
        trained_b = b;
    else
        if convergence(iteration)<=minObj
            minObj = convergence(iteration);
            trained_w = w;
            trained_b = b;
        end
        if abs(convergence(iteration) - convergence(iteration-1)) <= tol*convergence(iteration)
            fprintf('optimization converge at ratio difference %f\n',tol);
            break;
        end
    end
    if iteration <max_iter
%         fprintf('iteration: %d  loss: %.3f\n',iteration,convergence(iteration));
    else
        fprintf('exceed maximum iterations\n');
        break;
    end
end
trained_w = w;
trained_b = b;
end


function value = wbLoss(train_target,Y,w,Eps,conf,gamma)

[num_class,num_train] = size(train_target);

Ybar = num_class - Y;

firstTerm = sum(sum(w.^2,1));

secondTerm = 0;
for k = 1:num_class
    temp = 0;
    flag = 1;
    for i=1:num_train
        if train_target(k,i) == 1
            temp = temp + gamma(i,1)*conf(k,i)*sum(Eps{k,1}(flag:flag+Ybar(i)-1));
            flag = flag+Ybar(i);
            temp = temp + gamma(i,2)*sum(max(0,conf(k,i)-conf(train_target(:,i)==1,i)).*Eps{k,1}(flag:flag+Y(i)-1));
            flag = flag+Y(i);
        else
            temp = temp+gamma(i,1)*sum(conf(train_target(:,i)==1,i).*Eps{k,1}(flag:flag+Y(i)-1));
            flag = flag+Y(i);
        end
    end
    secondTerm = secondTerm+temp;
end
value = firstTerm + secondTerm;

end