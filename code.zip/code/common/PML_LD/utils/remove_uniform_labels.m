function [x_train, x_test, y_train, y_test, l_train, l_test] = remove_uniform_labels(x_train, x_test, y_train, y_test, l_train, l_test)
    % Check if there are columns in the training and testing sets with all zeros or all ones as labels
    % If such columns exist, remove them from both training and testing sets
    % Inputs:
    % x_train: Training data
    % x_test: Testing data
    % y_train: Training true labels
    % y_test: Testing true labels
    % l_train: Training noisy labels
    % l_test: Testing noisy labels
    % Outputs:
    % Processed data and label sets
    
    % Find columns in training and testing sets with all zeros or all ones
    cols_to_delete_y = find(all(y_test == 0, 1) | all(y_test == 1, 1));
    cols_to_delete_l = find(all(l_train == 0, 1) | all(l_train == 1, 1));

    rows_to_delete_y = find( all(y_test == 0, 2) | all(y_test == 1, 2));
    
    
    % Merge and remove duplicates from the arrays
    cols_to_delete = unique([cols_to_delete_y, cols_to_delete_l]);
    
    % Remove these columns from the training and testing sets
    y_train(:, cols_to_delete) = [];
    y_test(:, cols_to_delete) = [];
    l_train(:, cols_to_delete) = [];
    l_test(:, cols_to_delete) = [];
    
    x_test(rows_to_delete_y,:)=[];
    y_test(rows_to_delete_y,:)=[];

end