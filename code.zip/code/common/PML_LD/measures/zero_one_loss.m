function zero_one_loss = calculate_multi_label_zero_one_loss(y_pred, y_true)
    % 计算多标签分类的Zero-One Loss
    % 输入参数：
    %   y_pred: 模型的预测结果矩阵，每列表示一个样本，每行表示一个标签（矩阵）
    %   y_true: 真实的标签矩阵，每列表示一个样本，每行表示一个标签（矩阵）
    % 输出参数：
    %   zero_one_loss: 多标签分类的Zero-One Loss

    % 确保输入参数具有相同的大小
    assert(isequal(size(y_pred), size(y_true)), '输入参数大小不一致');

    % 计算Zero-One Loss
    incorrect_labels = any(y_pred ~= y_true, 1);  % 找到每个标签列中是否有任何不匹配的样本
    zero_one_loss = sum(incorrect_labels) / numel(incorrect_labels);
end
