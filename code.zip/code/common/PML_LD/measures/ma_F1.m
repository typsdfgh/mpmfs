function macroF1 = ma_F1(y_pred, y_test)
    %正样本1，负样本0
    y_pred(y_pred==-1)=0;
    y_test(y_test==-1)=0;
    y_pred=double(y_pred);
    y_test=double(y_test);
    % 计算每个类别的F1分数
    numClasses = size(y_test, 1);
    f1Scores = zeros(numClasses, 1);
    
    for i = 1:numClasses
        tp = sum((y_pred(i, :) == 1) & (y_test(i, :) == 1));
        fp = sum((y_pred(i, :) == 1) & (y_test(i, :) == 0));
        fn = sum((y_pred(i, :) == 0) & (y_test(i, :) == 1));
        
        if tp+fp == 0
            precision = 0;
        else
            precision = tp / (tp + fp);
        end
        if tp + fn==0
            recall=0;
        else
            recall = tp / (tp + fn);
        end
        
        % 避免除以零
        if (precision + recall) == 0
            f1Scores(i) = 0;
        else
            f1Scores(i) = 2 * (precision * recall) / (precision + recall);
        end
    end
    
    % 计算Macro-F1分数
    macroF1 = mean(f1Scores);
end
