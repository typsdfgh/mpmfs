clc
clear
addpath(genpath(pwd));
% 创建第一个多标签矩阵 y_pred
I = eye(3);
I(I==0)=-1;
disp(I);