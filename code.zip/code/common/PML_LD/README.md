# Paper
Partial Multi-Label Learning with Label Distribution. In: Proceedings of the 34th AAAI Conference on Artificial Intelligence (AAAI'20)
# Instruction
use the file `main.m` 