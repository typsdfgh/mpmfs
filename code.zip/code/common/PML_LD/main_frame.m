clc
clear
addpath(genpath(pwd));
%datasets = { 'birds','corel5k','llog_f', 'CAL500','CHD_49','yeast', 'water','HumanPseAAC','PlantPseAAC'};
datasets = {'HumanPseAAC','PlantPseAAC'};
n_fold = 10;
%cl_columns={'dataset','method','classifier','p','r','fs_num','k_no', 'AP_mi','HL', 'F1_ma', 'F1_mi','ONE','CE', 'RL','lambda1','lambda2'};
cl_columns = {'dataset','method','classifier','p','r','fs_num','k_no', 'AP_mi','HL', 'F1_ma', 'F1_mi','ONE','CE', 'RL','lambda1','lambda2'};

% 初始化空的struct
dataStruct = struct();

% 遍历列名，为每个列名创建一个空字段
for i = 1:length(cl_columns)
    dataStruct.(cl_columns{i}) = [];
end

cl_result_record({}, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pml_ld\PML_LD11.csv', dataStruct, 1);
cl_result_record({}, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pml_ld\PML_LD22.csv', dataStruct, 1);
for dataN = 1:13
    % load data
    Dataset = datasets{dataN};
    disp(Dataset);
    path = ['D:\Doc\PML-PYTHON\make_data\data/',Dataset,'.mat'];
    path =join(path, '');
    load(path);
    % preprocess
    n_sample = size(data, 1);
    data = normalize(data);
	
    % n_fold validation and evaluation
    for i = 1:n_fold
        fprintf('Data processing, Cross validation: %d\n', i);
        % split data
		[x_train, x_test, y_train, y_test, l_train, l_test] = split_data_fold(double(data), target', partial_labels', i, n_fold);
		[train_data, test_data, y_train, test_target, train_p_target, l_test] = remove_uniform_labels(x_train, x_test, y_train, y_test, l_train, l_test);
        % setup parameters for LE model
        param = importdata('arts_param.mat');
        param.tooloptions.maxiter = 50;
        param.tooloptions.gradnorm = 1e-3;
        param.tooloptions.stopfun = @mystopfun;
		param.g = 100;
        param.K = 10;
		lambda1= {0.001,1};
		lambda2= {0.001,1};
		for lamb1 = 1: 2
			for lamb2 = 1:2
				param.lambda1=lambda1{lamb1};
				param.lambda2=lambda2{lamb2};
				% LE process
				[~,numerical] = AMTrain(train_p_target, train_data,param);
				% save LE results
				%save_path = fullfile(save_folder,strcat('res',num2str(i)));
				%save(save_path, 'numerical');
				% ---------------------------------------------------------------------------------------
				numerical = (softmax(numerical'))';
				% setup parameters for classifier model
				tol  = 1e-10;   %Tolerance during the iteration
				epsi =0.1;      %Instances whose distance computed is more than epsi should be penalized
				ker  = 'rbf';   %Type of kernel function
				beta1=1;        %Penalty parameter
				beta2=50;       %Penalty parameter
				par = 1*mean(pdist(train_data));
				% training classifier model
				[Beta,b] = plmsvr(train_data,numerical,train_p_target,ker,beta1,beta2,epsi,par,tol);
				y_prob = PL_LEAF_predict(train_data,test_data,ker,Beta,b,par);

                y_pred = binaryzation(softmax(y_prob')',0.1);
                %bin_test_target = binaryzation(softmax(test_target)',0.1);
		        classification_result = struct();
				classification_result.dataset = Dataset;
				classification_result.method = 'PML_LD';
				classification_result.classifier = 'XW';
				classification_result.p = 0.3;
				classification_result.r = 1;
				classification_result.fs_num = 0;
				classification_result.k_no = i;
				classification_result.AP_mi = Average_precision(y_prob',test_target');
				classification_result.HL = Hamming_loss(y_pred',test_target');
				classification_result.F1_ma = ma_F1(y_pred',test_target');
				classification_result.F1_mi = mi_F1(y_pred',test_target');
				classification_result.ONE = One_error(y_prob',test_target');
				classification_result.CE = coverage(y_prob',test_target');  
				classification_result.RL = Ranking_loss(y_prob',test_target');
				classification_result.lambda1 = lambda1{lamb1};
				classification_result.lambda2 = lambda2{lamb2};
                cl_result_record(classification_result, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pml_ld\PML_LD22.csv', cl_columns, 0);
				% 获取参数矩阵W，
				W = get_W_process(test_data, y_pred) ;
             
                %disp(size(train_data));
                %disp(size(train_p_target));
                %disp(size(W));
				W_2 = sqrt(sum(W.^2, 2));
				[~, f_idx] = sort(W_2, 'descend');
				f_idx = f_idx.';
			    if size(train_data, 2) > 100
					select_num = round(size(train_data, 2) * 0.2);
					select_num_list = round(select_num * (1:20) / 20);
                elseif size(train_data, 2) < 20
                    select_num_list = 1:size(train_data, 2);
                else
                    select_num_list = 1:20;
                end
                for num = select_num_list
					data_test = test_data(:, f_idx(1:num));
					y_prob = data_test* W(f_idx(1:num),:);
                    y_pred=ones(size(y_prob));
                    y_pred(y_prob < 0.5)= -1;
					test_target(test_target == 0) = -1;
			
					classification_result = struct();
					classification_result.dataset = Dataset;
					classification_result.method = 'PML_LD';
					classification_result.classifier = 'XW';
					classification_result.p = 0.3;
					classification_result.r = 1;
					classification_result.fs_num = num;
					classification_result.k_no = i;
					classification_result.AP_mi = Average_precision(y_prob',test_target');
					classification_result.HL = Hamming_loss(y_pred',test_target');
					classification_result.F1_ma = ma_F1(y_pred',test_target');
					classification_result.F1_mi = mi_F1(y_pred',test_target');
					classification_result.ONE = One_error(y_prob',test_target');
					classification_result.CE = coverage(y_prob',test_target');  
					classification_result.RL = Ranking_loss(y_prob',test_target');
					classification_result.lambda1 = lambda1{lamb1};
					classification_result.lambda2 = lambda2{lamb2};
                    cl_result_record(classification_result, 'D:\Doc\PML-PYTHON\none_nega_feature_result_percent\pml_ld\PML_LD11.csv', cl_columns, 0);
                end
			end
		end
    end
end
