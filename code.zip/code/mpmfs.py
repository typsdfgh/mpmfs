# coding=UTF-8
import numpy as np
from numpy import linalg as LA
from skfeature.utility.construct_W import construct_W
from numpy.random import seed
eps = 2.2204e-16

def New(X_train,y_train,alpha,beta,gamma,lamda):
    seed(2)
    # X_train = np.matrix(X_train)
    # y_train = np.matrix(y_train)
    maxIter = 1000
    n, d = X_train.shape
    n, c = y_train.shape
    k =int (np.ceil(c/2))
    # print("K",k)
    I_L = np.ones_like(y_train)
    Y_t =  I_L - y_train 
    # print("Y_t.shape",Y_t.shape)
    U = abs((np.random.rand( n, k)))
    # print("U.shape",U.shape)
    V = abs((np.random.rand(k, c)))
    # print("V.shape",V.shape)
    W =abs((np.random.rand(d,c)))
    # print("W.shape",W.shape)
    Q = abs((np.random.rand(d,k)))
    # print("Q.shape",Q.shape)
    
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 3, 'weight_mode': 'heat_kernel', 't': 1.0}
    Sy = construct_W(Y_t, **options)
    # n=np.nonzero(Sx)
    # nonzero_elements = Sx[n]
    # print(nonzero_elements.shape)
    # print("非零元素的值:",nonzero_elements)
    # print("非零元素的索引:",n)
    # print(n)
    Sy = Sy.A
    Dy = np.diag(np.sum(Sy,axis=1))
    Ly=Dy -Sy

    iter = 0
    obj = []
    obji = 1
    while iter < maxIter:
        tem=W -Q @ V
        Btmp = np.sqrt(np.sum(np.multiply(tem, tem), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)
        # upata U
        # print(((alpha *Y_t @ V.T)).shape)
        # print(U.shape)
        # print((X_train @Q).shape)
        # print((alpha * U@V@V.T).shape)
        # print((2*gamma*Lx@U).shape)
      
        numerator_U= alpha *Y_t @ V.T +beta *X_train @Q+gamma*Sy@U
        # print("numerator_U.shape",  numerator_U.shape)
        denominator_U =alpha * U@V@V.T + beta * U + gamma*Dy@U
        # print("lx.shape", Lx.shape)
        # print("denominator_U.shape", denominator_U.shape)
        # print((np.true_divide(numerator_U, denominator_U + eps)).shape)
        U = U * np.true_divide(numerator_U, denominator_U + eps)

        #update V
        T0 = X_train@Q
        numerator_V= alpha *U.T@Y_t +T0.T @ I_L +lamda*Q.T@D@W
        denominator_V =alpha * U.T @U @V +T0.T @ T0 @V +T0.T@X_train@W+lamda*Q.T@D@Q@V
        V = V * np.true_divide(numerator_V, denominator_V + eps)

        #update Q
        numerator_Q= beta *X_train.T @U +X_train.T@ I_L @V.T+lamda*D@W@V.T
        denominator_Q = beta * X_train.T@X_train@Q +X_train.T @X_train@Q @V@V.T +X_train.T @X_train@W@V.T+lamda*D@Q@V@V.T
        Q = Q *np.true_divide(numerator_Q, denominator_Q + eps)

        #update W
        # print(( X_train.T @X_train@W).shape)
        # print((X_train.T@X_train@W).shape)
       
        numerator_W =X_train.T   @ I_L  +lamda*D@Q@V
        denominator_W = X_train.T @X_train@W +X_train.T@X_train@Q@V+lamda*D@W
        # print(( denominator_W).shape)
        W = W *np.true_divide(numerator_W, denominator_W + eps)




        object_tives =alpha* LA.norm(Y_t - U @V, 'fro')**2 + beta *LA.norm(U - X_train @ Q, 'fro')**2\
            + LA.norm(I_L -X_train @ Q @ V-X_train @ W, 'fro')**2 +gamma* np.trace(U.T @ Ly @U)+lamda*np.trace(np.dot(np.dot(tem.T, D),tem ))
        
        obj.append(object_tives)

        cver = abs((object_tives - obji) / float(obji))
        obji = object_tives
        iter = iter + 1
        if (iter %10==0):
            
            print("iter,obj:",iter, object_tives)
           
        if (iter > 2 and (cver < 200 or iter == 500)):
            break
        
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    l = [i for i in idx]
    
    W_=W -Q @ V
    return l,W,obj
def New1(X_train,y_train,alpha,beta,gamma,lamda):
    seed(2)
    # X_train = np.matrix(X_train)
    # y_train = np.matrix(y_train)
    maxIter = 1000
    n, d = X_train.shape
    n, c = y_train.shape
    k =int (np.ceil(c/2))
    # print("K",k)
    I_L = np.ones_like(y_train)
    Y_t =  I_L - y_train 
    # print("Y_t.shape",Y_t.shape)
    U = abs((np.random.rand( n, k)))
    # print("U.shape",U.shape)
    V = abs((np.random.rand(k, c)))
    # print("V.shape",V.shape)
    W =abs((np.random.rand(d,c)))
    # print("W.shape",W.shape)
    Q = abs((np.random.rand(d,k)))
    # print("Q.shape",Q.shape)
    
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 3, 'weight_mode': 'heat_kernel', 't': 1.0}
    Sy = construct_W(Y_t, **options)
    # n=np.nonzero(Sx)
    # nonzero_elements = Sx[n]
    # print(nonzero_elements.shape)
    # print("非零元素的值:",nonzero_elements)
    # print("非零元素的索引:",n)
    # print(n)
    Sy = Sy.A
    Dy = np.diag(np.sum(Sy,axis=1))
    Ly=Dy -Sy

    iter = 0
    obj = []
    obji = 1
    while iter < maxIter:
        tem = W
        Btmp = np.sqrt(np.sum(np.multiply(tem, tem), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)
        # upata U
        # print(((alpha *Y_t @ V.T)).shape)
        # print(U.shape)
        # print((X_train @Q).shape)
        # print((alpha * U@V@V.T).shape)
        # print((2*gamma*Lx@U).shape)
      
        numerator_U= alpha *Y_t @ V.T +beta *X_train @Q+gamma*Sy@U
        # print("numerator_U.shape",  numerator_U.shape)
        denominator_U =alpha * U@V@V.T + beta * U + gamma*Dy@U
        # print("lx.shape", Lx.shape)
        # print("denominator_U.shape", denominator_U.shape)
        # print((np.true_divide(numerator_U, denominator_U + eps)).shape)
        U = U * np.true_divide(numerator_U, denominator_U + eps)

        #update V
        T0 = X_train@Q
        numerator_V= alpha *U.T@Y_t +T0.T @ I_L 
        denominator_V =alpha * U.T @U @V +T0.T @ T0 @V +T0.T@X_train@W
        V = V * np.true_divide(numerator_V, denominator_V + eps)

        #update Q
        numerator_Q= beta *X_train.T @U +X_train.T@ I_L @V.T
        denominator_Q = beta * X_train.T@X_train@Q +X_train.T @X_train@Q @V@V.T +X_train.T @X_train@W@V.T
        Q = Q *np.true_divide(numerator_Q, denominator_Q + eps)

        #update W
        # print(( X_train.T @X_train@W).shape)
        # print((X_train.T@X_train@W).shape)
       
        numerator_W =X_train.T   @ I_L  
        denominator_W = X_train.T @X_train@W +X_train.T@X_train@Q@V+lamda*D@W
        # print(( denominator_W).shape)
        W = W *np.true_divide(numerator_W, denominator_W + eps)




        object_tives =alpha* LA.norm(Y_t - U @V, 'fro')**2 + beta *LA.norm(U - X_train @ Q, 'fro')**2\
            + LA.norm(I_L -X_train @ Q @ V-X_train @ W, 'fro')**2 +gamma* np.trace(U.T @ Ly @U)+lamda*np.trace(np.dot(np.dot(tem.T, D),tem ))
        
        obj.append(object_tives)

        cver = abs((object_tives - obji) / float(obji))
        obji = object_tives
        iter = iter + 1
        if (iter %10==0):
            
            print("iter,obj:",iter, object_tives)
           
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break
        
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    l = [i for i in idx]
    
    W_=W -Q @ V
    return l,W
def New2(X_train,y_train,alpha,beta,gamma,lamda):
    seed(2)
    # X_train = np.matrix(X_train)
    # y_train = np.matrix(y_train)
    maxIter = 1000
    n, d = X_train.shape
    n, c = y_train.shape
    k =int (np.ceil(c/2))
    # print("K",k)
    I_L = np.ones_like(y_train)
    Y_t =  I_L - y_train 
    # print("Y_t.shape",Y_t.shape)
    U = abs((np.random.rand( n, k)))
    # print("U.shape",U.shape)
    V = abs((np.random.rand(k, c)))
    # print("V.shape",V.shape)
    W =abs((np.random.rand(d,c)))
    # print("W.shape",W.shape)
    Q = abs((np.random.rand(d,c)))
    # print("Q.shape",Q.shape)
    
    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 3, 'weight_mode': 'heat_kernel', 't': 1.0}
    Sy = construct_W(Y_t, **options)
    # n=np.nonzero(Sx)
    # nonzero_elements = Sx[n]
    # print(nonzero_elements.shape)
    # print("非零元素的值:",nonzero_elements)
    # print("非零元素的索引:",n)
    # print(n)
    Sy = Sy.A
    Dy = np.diag(np.sum(Sy,axis=1))
    Ly=Dy -Sy

    iter = 0
    obj = []
    obji = 1
    while iter < maxIter:
        tem = W - Q
        Btmp = np.sqrt(np.sum(np.multiply(tem, tem), 1) + eps)
        d1 = 0.5 / Btmp
        D = np.diag(d1.flat)
        # upata U
        # print(((alpha *Y_t @ V.T)).shape)
        # print(U.shape)
        # print((X_train @Q).shape)
        # print((alpha * U@V@V.T).shape)
        # print((2*gamma*Lx@U).shape)
      
      

        #update Q
        numerator_Q= beta *X_train.T @Y_t +X_train.T@ I_L +lamda*D@W
        denominator_Q = beta * X_train.T@X_train@Q +X_train.T @X_train@Q  +X_train.T @X_train@W+lamda*D@Q
        Q = Q *np.true_divide(numerator_Q, denominator_Q + eps)

        #update W
        # print(( X_train.T @X_train@W).shape)
        # print((X_train.T@X_train@W).shape)
       
        numerator_W =X_train.T   @ I_L  +lamda*D@Q
        denominator_W = X_train.T @X_train@W +X_train.T@X_train@Q+lamda*D@W
        # print(( denominator_W).shape)
        W = W *np.true_divide(numerator_W, denominator_W + eps)




        object_tives =  beta *LA.norm(Y_t - X_train @ Q, 'fro')**2\
            + LA.norm(I_L -X_train @ Q -X_train @ W, 'fro')**2 +lamda*np.trace(np.dot(np.dot(tem.T, D),tem ))
        
        obj.append(object_tives)

        cver = abs((object_tives - obji) / float(obji))
        obji = object_tives
        iter = iter + 1
        if (iter %10==0):
            
            print("iter,obj:",iter, object_tives)
           
        if (iter > 2 and (cver < 1e-3 or iter == 1000)):
            break
        
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    l = [i for i in idx]
    
    W_=W -Q
    return l,W_